from __future__ import annotations

import io
from typing import Iterable

import pandas as pd
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from analyzer import AnalysisResult


SHEETS = (
    ("Application Summary", "application_summary"),
    ("Record Type Summary", "type_summary"),
    ("Priority Breakdown", "priority_summary"),
    ("Category Breakdown", "category_summary"),
    ("Recurring Issues", "recurring_issues"),
    ("Problem Candidates", "problem_candidates"),
    ("Change Correlations", "correlations"),
    ("ECR Opportunities", "ecr_opportunities"),
    ("SLA Breaches", "sla_breaches"),
    ("Aging Tickets", "aging_tickets"),
    ("Action Items", "action_items"),
    ("Normalized Records", "records"),
)


def _safe_for_excel(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    for column in result.columns:
        if pd.api.types.is_datetime64_any_dtype(result[column]):
            result[column] = result[column].dt.tz_localize(None)
    return result


def build_excel(result: AnalysisResult) -> bytes:
    stream = io.BytesIO()
    with pd.ExcelWriter(stream, engine="openpyxl") as writer:
        executive = pd.DataFrame(
            [{"Metric": key.replace("_", " ").title(), "Value": value} for key, value in result.executive.items()]
        )
        executive.to_excel(writer, sheet_name="Executive Summary", index=False)
        for sheet_name, attribute in SHEETS:
            frame = _safe_for_excel(getattr(result, attribute))
            frame.to_excel(writer, sheet_name=sheet_name[:31], index=False)
        if result.ingestion_warnings:
            pd.DataFrame({"Warning": result.ingestion_warnings}).to_excel(
                writer, sheet_name="Ingestion Warnings", index=False
            )

        for worksheet in writer.book.worksheets:
            worksheet.freeze_panes = "A2"
            worksheet.auto_filter.ref = worksheet.dimensions
            for cell in worksheet[1]:
                cell.fill = PatternFill("solid", fgColor="17365D")
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center")
            for idx, column_cells in enumerate(worksheet.columns, start=1):
                width = max((len(str(cell.value or "")) for cell in column_cells), default=8)
                worksheet.column_dimensions[get_column_letter(idx)].width = min(max(width + 2, 12), 48)
    return stream.getvalue()


def _add_table(document: Document, headers: Iterable[str], rows: Iterable[Iterable[object]]) -> None:
    headers = list(headers)
    table = document.add_table(rows=1, cols=len(headers))
    table.style = "Light Shading Accent 1"
    for index, header in enumerate(headers):
        table.rows[0].cells[index].text = str(header)
    for values in rows:
        cells = table.add_row().cells
        for index, value in enumerate(values):
            cells[index].text = "" if pd.isna(value) else str(value)


def build_management_docx(result: AnalysisResult) -> bytes:
    document = Document()
    section = document.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    title = document.add_heading("Enterprise Service Management Analysis", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    subtitle = document.add_paragraph(f"Management Summary | Generated {result.generated_at[:10]}")
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

    document.add_heading("Executive Summary", level=1)
    e = result.executive
    document.add_paragraph(
        f"The analysis processed {e['total_records']} ServiceNow records across "
        f"{e['applications']} applications. It identified {e['recurring_patterns']} recurring "
        f"patterns, {e['problem_candidates']} problem candidates, {e['correlations']} potential "
        f"incident/change correlations, and {e['ecr_opportunities']} opportunities to convert "
        f"repeat emergency activity into controlled standard changes or automation."
    )
    metrics = [
        ("Incidents", e["incidents"]), ("Standard changes", e["standard_changes"]),
        ("Normal changes", e["normal_changes"]), ("ECRs", e["ecrs"]),
        ("Problems", e["problems"]), ("RITMs", e["ritms"]),
        ("SLA breaches", e["sla_breaches"]), ("Open records", e["open_records"]),
    ]
    _add_table(document, ["Metric", "Count"], metrics)

    document.add_heading("Application Overview", level=1)
    app_totals = (
        result.records.groupby("application").size().sort_values(ascending=False).head(15).reset_index(name="Records")
    )
    _add_table(document, ["Application", "Records"], app_totals.itertuples(index=False, name=None))

    document.add_heading("Top Recurring Issues", level=1)
    top = result.recurring_issues.head(10)
    if top.empty:
        document.add_paragraph("No repeated incident pattern met the recurrence threshold.")
    else:
        _add_table(
            document,
            ["Application", "Issue Category", "Pattern", "Count"],
            top[["application", "issue_category", "signature", "count"]].itertuples(index=False, name=None),
        )

    document.add_heading("Management Action Plan", level=1)
    _add_table(
        document,
        ["Priority", "Application", "Area", "Action", "Evidence"],
        result.action_items.head(20).itertuples(index=False, name=None),
    )

    document.add_heading("Data Quality Notes", level=1)
    if result.ingestion_warnings:
        for warning in result.ingestion_warnings:
            document.add_paragraph(warning, style="List Bullet")
    else:
        document.add_paragraph("All uploaded files were ingested without warnings.")

    styles = document.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(9)
    stream = io.BytesIO()
    document.save(stream)
    return stream.getvalue()
