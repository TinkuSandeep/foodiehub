import io

import pandas as pd

from analyzer import analyze, normalize_frame, read_tabular_bytes
from report_generator import build_excel, build_management_docx


def _incidents():
    return pd.DataFrame({
        "Number": ["INC001", "INC002", "INC003", "INC004"],
        "Application": ["ODIN [CI100]", "ODIN [CI100]", "ODIN [CI100]", "Lenel"],
        "Priority": ["P2", "P3", "P3", "P2"],
        "State": ["Closed", "Closed", "Open", "Closed"],
        "Opened at": ["2026-01-02 10:00", "2026-01-03 10:00", "2026-01-05 10:00", "2026-01-06 10:00"],
        "Closed at": ["2026-01-02 12:00", "2026-01-03 12:00", None, "2026-01-06 12:00"],
        "Short description": [
            "Upstream file not received", "Upstream file not received",
            "Upstream file not received", "Service unavailable after CHG100",
        ],
        "Caused by Change": ["", "", "", "CHG100"],
        "SLA Breached": ["No", "Yes", "No", "No"],
    })


def test_normalize_and_analyze():
    incidents = normalize_frame(_incidents(), "incident", "incidents.xlsx")
    changes = normalize_frame(pd.DataFrame({
        "Number": ["CHG100"], "Application": ["Lenel"], "State": ["Closed"],
        "Opened": ["2026-01-06 09:00"], "Short Description": ["Restart service"],
    }), "normal_change", "changes.xlsx")
    result = analyze({"incident": [incidents], "normal_change": [changes]})
    assert result.executive["incidents"] == 4
    assert result.executive["problem_candidates"] == 1
    assert result.executive["correlations"] >= 1
    assert set(result.records["application"]) == {"ODIN", "Lenel"}


def test_excel_intro_and_reports():
    stream = io.BytesIO()
    with pd.ExcelWriter(stream, engine="openpyxl") as writer:
        pd.DataFrame([["ServiceNow Export"], [None]]).to_excel(writer, sheet_name="Instructions", header=False, index=False)
        _incidents().to_excel(writer, sheet_name="Data", index=False)
    parsed = read_tabular_bytes(stream.getvalue(), "incidents.xlsx")
    result = analyze({"incident": [normalize_frame(parsed, "incident")]})
    assert len(result.records) == 4
    assert build_excel(result)[:2] == b"PK"
    assert build_management_docx(result)[:2] == b"PK"
