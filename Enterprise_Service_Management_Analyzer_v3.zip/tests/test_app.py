import io

import pandas as pd
from fastapi.testclient import TestClient

from app import app


client = TestClient(app)


def _xlsx_bytes() -> bytes:
    stream = io.BytesIO()
    pd.DataFrame({
        "Number": ["INC9001", "INC9002", "INC9003"],
        "Application": ["ODIN", "ODIN", "ODIN"],
        "State": ["Closed", "Closed", "Open"],
        "Opened": ["2026-01-01", "2026-01-02", "2026-01-03"],
        "Short Description": [
            "Upstream source file delayed",
            "Upstream source file delayed",
            "Upstream source file delayed",
        ],
    }).to_excel(stream, index=False)
    return stream.getvalue()


def test_full_upload_and_download_flow():
    home = client.get("/")
    assert home.status_code == 200
    assert "Enterprise Service Management Analyzer" in home.text

    response = client.post(
        "/analyze",
        files={"incidents": ("incidents.xlsx", _xlsx_bytes(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")},
    )
    assert response.status_code == 200
    assert "Problem Candidates" in response.text

    marker = '/download/'
    start = response.text.index(marker) + len(marker)
    analysis_id = response.text[start:].split("/", 1)[0]
    excel = client.get(f"/download/{analysis_id}/xlsx")
    docx = client.get(f"/download/{analysis_id}/docx")
    pack = client.get(f"/download/{analysis_id}/zip")
    assert excel.status_code == docx.status_code == pack.status_code == 200
    assert excel.content[:2] == docx.content[:2] == pack.content[:2] == b"PK"
