from __future__ import annotations

import io
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable

import pandas as pd


RECORD_TYPES = ("incident", "standard_change", "normal_change", "ecr", "problem", "ritm")

COLUMN_ALIASES: dict[str, tuple[str, ...]] = {
    "number": ("number", "ticket number", "record number", "incident", "change number", "problem number", "request number"),
    "application": (
        "application", "application name", "business application", "configuration item",
        "configuration item.name", "cmdb ci", "cmdb_ci", "service", "affected application",
    ),
    "priority": ("priority", "incident priority", "severity", "impact priority"),
    "state": ("state", "status", "incident state", "change state", "problem state"),
    "opened_at": ("opened", "opened at", "opened_at", "created", "created at", "sys created on", "start date"),
    "closed_at": ("closed", "closed at", "closed_at", "resolved", "resolved at", "end date", "actual end"),
    "short_description": ("short description", "short_description", "title", "summary"),
    "description": ("description", "details", "work notes", "additional comments"),
    "assignment_group": ("assignment group", "assignment_group", "support group", "assigned group"),
    "category": ("category",),
    "subcategory": ("subcategory", "sub category"),
    "cause": ("cause", "root cause", "root_cause", "probable cause"),
    "close_notes": ("close notes", "close_notes", "resolution notes", "resolution", "closure notes"),
    "change_type": ("type", "change type", "change_type", "request type"),
    "risk": ("risk", "risk level", "risk_level"),
    "parent": ("parent", "parent ticket", "parent number"),
    "problem_id": ("problem", "problem id", "problem number", "problem_id"),
    "caused_by_change": ("caused by change", "caused_by_change", "related change", "change request"),
    "sla_breached": ("sla breached", "made sla", "sla breach", "breached", "has breached"),
    "close_code": ("close code", "closure code", "result", "outcome"),
}

ISSUE_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("Upstream delay", ("upstream", "late file", "file delay", "not received", "delayed feed", "source delay", "waiting for file")),
    ("Invalid data", ("invalid data", "bad data", "incorrect data", "malformed", "data issue", "validation failed")),
    ("Extra characters", ("extra character", "special character", "unexpected character", "trailing character")),
    ("Column size", ("column size", "truncat", "value too long", "data too long", "length exceeded", "field size")),
    ("Batch / job failure", ("autosys", "ssis", "batch job", "job fail", "scheduler", "file watcher")),
    ("Database", ("database", "sql server", "oracle", "deadlock", "blocking", "listener", "connection pool")),
    ("Access / authentication", ("access denied", "unauthorized", "authentication", "login fail", "permission", "401", "403")),
    ("Performance", ("slow", "latency", "timeout", "performance", "response time", "high cpu", "memory")),
    ("Network", ("network", "dns", "firewall", "connection reset", "unreachable", "proxy")),
    ("Infrastructure", ("server", "disk", "cpu", "memory", "vm", "pod", "container", "ocp", "kubernetes")),
    ("Application / service", ("service down", "application down", "service stopped", "unavailable", "api fail", "500", "503")),
    ("Monitoring noise", ("false alert", "false positive", "suppression", "monitoring noise", "duplicate alert")),
)

STOP_WORDS = {
    "the", "and", "for", "from", "with", "this", "that", "was", "were", "are", "not",
    "has", "have", "had", "into", "after", "before", "issue", "incident", "failed", "failure",
    "error", "unable", "team", "application", "production", "prod", "service", "ticket",
}


@dataclass
class AnalysisResult:
    generated_at: str
    records: pd.DataFrame
    executive: dict[str, Any]
    application_summary: pd.DataFrame
    type_summary: pd.DataFrame
    category_summary: pd.DataFrame
    priority_summary: pd.DataFrame
    recurring_issues: pd.DataFrame
    correlations: pd.DataFrame
    problem_candidates: pd.DataFrame
    ecr_opportunities: pd.DataFrame
    sla_breaches: pd.DataFrame
    aging_tickets: pd.DataFrame
    action_items: pd.DataFrame
    ingestion_warnings: list[str] = field(default_factory=list)


def _key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value).strip().lower()).strip()


def _clean_application(value: Any) -> str:
    if pd.isna(value) or not str(value).strip():
        return "Unknown"
    text = str(value).strip()
    text = re.sub(r"\s*\[[^\]]+\]\s*$", "", text)
    text = re.sub(r"\s+\|\s*(dev|test|uat|prod|production|bcp)\s*$", "", text, flags=re.I)
    return re.sub(r"\s+", " ", text).strip() or "Unknown"


def _column_map(columns: Iterable[Any]) -> dict[str, str]:
    normalized = {_key(col): str(col) for col in columns}
    result: dict[str, str] = {}
    for canonical, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if _key(alias) in normalized:
                result[canonical] = normalized[_key(alias)]
                break
    return result


def _header_score(frame: pd.DataFrame) -> int:
    return len(_column_map(frame.columns))


def _best_header(raw: pd.DataFrame) -> pd.DataFrame:
    best = raw.copy()
    best_score = _header_score(best)
    for row_index in range(min(15, len(raw))):
        candidate = raw.iloc[row_index + 1 :].copy()
        candidate.columns = raw.iloc[row_index].astype(str).str.strip()
        candidate = candidate.dropna(how="all")
        score = _header_score(candidate)
        if score > best_score:
            best, best_score = candidate, score
    return best


def read_tabular_bytes(content: bytes, filename: str) -> pd.DataFrame:
    """Read CSV/XLSX exports, including intro sheets and displaced header rows."""
    suffix = filename.lower().rsplit(".", 1)[-1] if "." in filename else ""
    if suffix in {"csv", "txt"}:
        last_error: Exception | None = None
        for encoding in ("utf-8-sig", "utf-8", "cp1252"):
            try:
                raw = pd.read_csv(io.BytesIO(content), dtype=object, encoding=encoding)
                return _best_header(raw)
            except Exception as exc:  # pragma: no cover - only used for fallback encodings
                last_error = exc
        raise ValueError(f"Unable to read {filename}: {last_error}")

    try:
        sheets = pd.read_excel(io.BytesIO(content), sheet_name=None, dtype=object, header=None)
    except Exception as exc:
        raise ValueError(f"Unable to read {filename} as Excel: {exc}") from exc

    candidates: list[tuple[int, int, pd.DataFrame]] = []
    for raw in sheets.values():
        if raw.dropna(how="all").empty:
            continue
        raw = raw.dropna(how="all").dropna(axis=1, how="all")
        frame = _best_header(raw)
        candidates.append((_header_score(frame), int(frame.notna().sum().sum()), frame))
    if not candidates:
        raise ValueError(f"{filename} contains no usable data")
    return max(candidates, key=lambda item: (item[0], item[1]))[2]


def _parse_datetime(series: pd.Series) -> pd.Series:
    if series.empty:
        return pd.Series(dtype="datetime64[ns, UTC]")
    return pd.to_datetime(series, errors="coerce", format="mixed", utc=True)


def _is_breach(value: Any) -> bool:
    text = _key(value)
    if text in {"true", "yes", "y", "1", "breached", "sla breached"}:
        return True
    if text in {"false", "no", "n", "0", "made sla", "met"}:
        return False
    return False


def _issue_category(text: str) -> str:
    lowered = text.lower()
    for label, terms in ISSUE_RULES:
        if any(term in lowered for term in terms):
            return label
    return "Other"


def _signature(text: str) -> str:
    cleaned = re.sub(r"\b(?:inc|chg|prb|ritm)\d+\b", " ", text.lower())
    cleaned = re.sub(r"\b\d+\b|[^a-z0-9\s]", " ", cleaned)
    words = [word for word in cleaned.split() if len(word) > 2 and word not in STOP_WORDS]
    if not words:
        return "uncategorized"
    counts = Counter(words)
    ranked = sorted(counts, key=lambda word: (-counts[word], word))
    return " ".join(ranked[:6])


def normalize_frame(frame: pd.DataFrame, kind: str, source_file: str = "") -> pd.DataFrame:
    if kind not in RECORD_TYPES:
        raise ValueError(f"Unsupported record type: {kind}")
    mapping = _column_map(frame.columns)
    if not mapping:
        raise ValueError(f"{source_file or 'Upload'} does not contain recognizable ServiceNow columns")

    output = pd.DataFrame(index=frame.index)
    text_fields = (
        "number", "application", "priority", "state", "short_description", "description",
        "assignment_group", "category", "subcategory", "cause", "close_notes",
        "change_type", "risk", "parent", "problem_id", "caused_by_change", "close_code",
    )
    for field in text_fields:
        output[field] = frame[mapping[field]].fillna("").astype(str).str.strip() if field in mapping else ""

    empty_dates = pd.Series(pd.NaT, index=frame.index, dtype="datetime64[ns, UTC]")
    output["opened_at"] = _parse_datetime(frame[mapping["opened_at"]]) if "opened_at" in mapping else empty_dates
    output["closed_at"] = _parse_datetime(frame[mapping["closed_at"]]) if "closed_at" in mapping else empty_dates.copy()
    output["sla_breached"] = frame[mapping["sla_breached"]].map(_is_breach) if "sla_breached" in mapping else False
    output["record_type"] = kind
    output["source_file"] = source_file
    output["application"] = output["application"].map(_clean_application)

    prefix = {
        "incident": "INC-AUTO", "standard_change": "CHG-STD-AUTO", "normal_change": "CHG-NRM-AUTO",
        "ecr": "CHG-ECR-AUTO", "problem": "PRB-AUTO", "ritm": "RITM-AUTO",
    }[kind]
    missing_number = output["number"].eq("")
    output.loc[missing_number, "number"] = [f"{prefix}-{i + 1:06d}" for i in range(missing_number.sum())]

    combined = (
        output["short_description"] + " " + output["description"] + " " +
        output["cause"] + " " + output["close_notes"]
    ).str.strip()
    output["issue_category"] = combined.map(_issue_category)
    output["signature"] = combined.map(_signature)
    now = pd.Timestamp.now(tz="UTC")
    end = output["closed_at"].fillna(now)
    output["duration_hours"] = ((end - output["opened_at"]).dt.total_seconds() / 3600).round(2)
    output.loc[output["duration_hours"] < 0, "duration_hours"] = pd.NA
    output["is_open"] = ~output["state"].str.lower().isin(
        {"closed", "resolved", "cancelled", "canceled", "complete", "completed", "successful", "success"}
    ) & output["closed_at"].isna()
    output["age_days"] = (output["duration_hours"] / 24).round(1)
    return output.reset_index(drop=True)


def _summary(records: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    if records.empty:
        return pd.DataFrame(columns=by + ["total", "open", "sla_breaches", "avg_resolution_hours"])
    result = (
        records.groupby(by, dropna=False)
        .agg(
            total=("number", "count"),
            open=("is_open", "sum"),
            sla_breaches=("sla_breached", "sum"),
            avg_resolution_hours=("duration_hours", "mean"),
        )
        .reset_index()
    )
    result["avg_resolution_hours"] = result["avg_resolution_hours"].round(1)
    return result.sort_values("total", ascending=False).reset_index(drop=True)


def _correlate(records: pd.DataFrame) -> pd.DataFrame:
    incidents = records[records["record_type"] == "incident"]
    changes = records[records["record_type"].isin(["standard_change", "normal_change", "ecr"])]
    rows: list[dict[str, Any]] = []
    change_numbers = {row.number.upper(): row for row in changes.itertuples()}

    for inc in incidents.itertuples():
        explicit = str(inc.caused_by_change).upper().strip()
        combined = f"{inc.short_description} {inc.description} {inc.close_notes}".upper()
        matched = change_numbers.get(explicit)
        reason, confidence = ("Explicit caused-by-change field", "High") if matched else ("", "")
        if not matched:
            for number, change in change_numbers.items():
                if number and number in combined:
                    matched, reason, confidence = change, "Change number referenced in incident", "High"
                    break
        if not matched and pd.notna(inc.opened_at):
            candidates = changes[
                (changes["application"] == inc.application)
                & changes["opened_at"].notna()
                & ((changes["opened_at"] - inc.opened_at).abs() <= pd.Timedelta(hours=72))
            ]
            if not candidates.empty:
                candidate = candidates.assign(
                    gap=(candidates["opened_at"] - inc.opened_at).abs()
                ).sort_values("gap").iloc[0]
                matched = candidate
                reason, confidence = "Same application within 72-hour change window", "Medium"
        if matched is not None:
            get = (lambda name: getattr(matched, name)) if hasattr(matched, "_fields") else (lambda name: matched[name])
            rows.append({
                "incident": inc.number, "change": get("number"), "application": inc.application,
                "change_type": get("record_type"), "confidence": confidence, "reason": reason,
                "incident_opened": inc.opened_at, "change_opened": get("opened_at"),
            })
    return pd.DataFrame(rows, columns=[
        "incident", "change", "application", "change_type", "confidence", "reason",
        "incident_opened", "change_opened",
    ])


def _recurring(records: pd.DataFrame) -> pd.DataFrame:
    incidents = records[records["record_type"] == "incident"]
    if incidents.empty:
        return pd.DataFrame(columns=["application", "signature", "issue_category", "count", "tickets", "linked_problem"])
    result = (
        incidents.groupby(["application", "signature", "issue_category"], dropna=False)
        .agg(
            count=("number", "count"),
            tickets=("number", lambda values: ", ".join(map(str, list(values)[:12]))),
            linked_problem=("problem_id", lambda values: ", ".join(sorted({v for v in values if v}))),
        )
        .reset_index()
    )
    return result[result["count"] >= 2].sort_values("count", ascending=False).reset_index(drop=True)


def _problem_candidates(recurring: pd.DataFrame) -> pd.DataFrame:
    if recurring.empty:
        return pd.DataFrame(columns=["application", "signature", "issue_category", "incident_count", "reason", "recommended_action"])
    candidates = recurring[(recurring["count"] >= 3) & recurring["linked_problem"].eq("")].copy()
    candidates = candidates.rename(columns={"count": "incident_count"})
    candidates["reason"] = candidates["incident_count"].map(lambda n: f"{n} similar incidents with no linked problem")
    candidates["recommended_action"] = "Open a Problem record; complete RCA, known error, and permanent-fix tracking"
    return candidates[[
        "application", "signature", "issue_category", "incident_count", "tickets", "reason", "recommended_action"
    ]].reset_index(drop=True)


def _ecr_opportunities(records: pd.DataFrame) -> pd.DataFrame:
    ecrs = records[records["record_type"] == "ecr"]
    if ecrs.empty:
        return pd.DataFrame(columns=["application", "signature", "ecr_count", "tickets", "opportunity"])
    grouped = (
        ecrs.groupby(["application", "signature"])
        .agg(ecr_count=("number", "count"), tickets=("number", lambda values: ", ".join(map(str, values))))
        .reset_index()
    )
    grouped = grouped[grouped["ecr_count"] >= 2].sort_values("ecr_count", ascending=False)
    grouped["opportunity"] = "Review for a pre-approved Standard Change or preventive automation"
    return grouped.reset_index(drop=True)


def _actions(
    records: pd.DataFrame,
    problem_candidates: pd.DataFrame,
    ecr_opportunities: pd.DataFrame,
    correlations: pd.DataFrame,
) -> pd.DataFrame:
    actions: list[dict[str, str]] = []
    for row in problem_candidates.head(10).itertuples():
        actions.append({
            "priority": "High", "application": row.application, "area": "Problem Management",
            "action": f"Create a Problem for recurring pattern: {row.signature}",
            "evidence": f"{row.incident_count} related incidents",
        })
    for row in ecr_opportunities.head(10).itertuples():
        actions.append({
            "priority": "High", "application": row.application, "area": "Change Management",
            "action": "Assess repeat ECR for Standard Change conversion and automation",
            "evidence": f"{row.ecr_count} similar emergency changes",
        })
    breaches = records[(records["record_type"] == "incident") & records["sla_breached"]]
    for application, group in breaches.groupby("application"):
        actions.append({
            "priority": "High", "application": application, "area": "SLA",
            "action": "Review breached incidents and improve escalation/runbook coverage",
            "evidence": f"{len(group)} SLA breaches",
        })
    if not correlations.empty:
        for application, group in correlations.groupby("application"):
            actions.append({
                "priority": "Medium", "application": application, "area": "Change Quality",
                "action": "Review correlated incidents during PIR and strengthen validation",
                "evidence": f"{len(group)} incident/change correlations",
            })
    if not actions:
        actions.append({
            "priority": "Low", "application": "Enterprise", "area": "Data Quality",
            "action": "Continue monthly ingestion and validate ServiceNow field completeness",
            "evidence": f"{len(records)} records analyzed",
        })
    return pd.DataFrame(actions)


def analyze(frames: dict[str, list[pd.DataFrame]], warnings: list[str] | None = None) -> AnalysisResult:
    normalized: list[pd.DataFrame] = []
    for kind, items in frames.items():
        for item in items:
            normalized.append(item)
    if not normalized:
        raise ValueError("No valid records were supplied")
    records = pd.concat(normalized, ignore_index=True)
    records = records.drop_duplicates(subset=["record_type", "number"], keep="last").reset_index(drop=True)

    recurring = _recurring(records)
    correlations = _correlate(records)
    problem_candidates = _problem_candidates(recurring)
    ecr_opportunities = _ecr_opportunities(records)
    sla_breaches = records[records["sla_breached"]].copy()
    aging = records[records["is_open"] & (records["age_days"] >= 7)].sort_values("age_days", ascending=False)
    actions = _actions(records, problem_candidates, ecr_opportunities, correlations)

    counts = records["record_type"].value_counts()
    executive = {
        "total_records": int(len(records)),
        "applications": int(records["application"].nunique()),
        "incidents": int(counts.get("incident", 0)),
        "standard_changes": int(counts.get("standard_change", 0)),
        "normal_changes": int(counts.get("normal_change", 0)),
        "ecrs": int(counts.get("ecr", 0)),
        "problems": int(counts.get("problem", 0)),
        "ritms": int(counts.get("ritm", 0)),
        "sla_breaches": int(records["sla_breached"].sum()),
        "open_records": int(records["is_open"].sum()),
        "recurring_patterns": int(len(recurring)),
        "problem_candidates": int(len(problem_candidates)),
        "correlations": int(len(correlations)),
        "ecr_opportunities": int(len(ecr_opportunities)),
    }
    return AnalysisResult(
        generated_at=datetime.now(timezone.utc).isoformat(),
        records=records,
        executive=executive,
        application_summary=_summary(records, ["application", "record_type"]),
        type_summary=_summary(records, ["record_type"]),
        category_summary=_summary(records, ["issue_category"]),
        priority_summary=_summary(records[records["record_type"] == "incident"], ["priority"]),
        recurring_issues=recurring,
        correlations=correlations,
        problem_candidates=problem_candidates,
        ecr_opportunities=ecr_opportunities,
        sla_breaches=sla_breaches,
        aging_tickets=aging,
        action_items=actions,
        ingestion_warnings=warnings or [],
    )
