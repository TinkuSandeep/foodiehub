# Enterprise Service Management Analyzer v3

This FastAPI application analyzes ServiceNow exports across applications and produces management-ready insights.

## Supported records

- Incidents (required)
- Standard Changes
- Normal Changes
- Emergency Change Requests (ECRs)
- Problems
- Requested Items (RITMs)

Each upload accepts one or more `.xlsx`, `.xls`, `.csv`, or `.txt` exports. The ingestion layer tolerates introductory Excel sheets, displaced headers, mixed date formats, missing optional fields, duplicate records, and common ServiceNow column-name variations.

## Analysis delivered

- Application-wise and record-type aggregation
- Incident categorization, including upstream delay, invalid data, extra characters, column-size issues, Autosys/SSIS failures, database, access, performance, network and infrastructure
- SLA-breach and aging-ticket analysis
- Recurring-incident detection
- Problem-record candidates when three or more similar incidents have no linked problem
- Incident/change correlation using explicit links, ticket references and same-application time proximity
- Repeat ECR detection and Standard Change/automation conversion opportunities
- Enterprise Excel workbook with detailed sheets
- Word management summary and combined ZIP report pack

## Run locally

```bash
python -m venv .venv
```

Windows:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run.py
```

Linux/macOS:

```bash
source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Open `http://localhost:8000`.

## Production roadmap

The prototype intentionally keeps uploaded files and results in memory. The next enterprise layer is direct ServiceNow/CMDB ingestion, PostgreSQL persistence, SSO/RBAC, background processing, scheduled MBR delivery, Outlook/email integration, audit logs, configurable classification rules, and retention controls.
