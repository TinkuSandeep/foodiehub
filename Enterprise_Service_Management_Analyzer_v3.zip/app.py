from __future__ import annotations

import io
import zipfile
from dataclasses import asdict
from pathlib import Path
from typing import Annotated
from uuid import uuid4

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, Response
from fastapi.templating import Jinja2Templates

from analyzer import AnalysisResult, RECORD_TYPES, analyze, normalize_frame, read_tabular_bytes
from report_generator import build_excel, build_management_docx


BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
app = FastAPI(title="Enterprise Service Management Analyzer", version="3.0.0")
RESULTS: dict[str, AnalysisResult] = {}
MAX_RESULTS = 20


def _store(result: AnalysisResult) -> str:
    analysis_id = uuid4().hex
    RESULTS[analysis_id] = result
    while len(RESULTS) > MAX_RESULTS:
        RESULTS.pop(next(iter(RESULTS)))
    return analysis_id


async def _ingest(kind: str, uploads: list[UploadFile] | None, warnings: list[str]) -> list:
    frames = []
    for upload in uploads or []:
        if not upload.filename:
            continue
        try:
            content = await upload.read()
            raw = read_tabular_bytes(content, upload.filename)
            frames.append(normalize_frame(raw, kind, upload.filename))
        except Exception as exc:
            warnings.append(f"{upload.filename}: {exc}")
    return frames


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={})


@app.get("/health")
async def health():
    return {"status": "ok", "version": app.version}


@app.post("/analyze", response_class=HTMLResponse)
async def analyze_uploads(
    request: Request,
    incidents: Annotated[list[UploadFile] | None, File()] = None,
    standard_changes: Annotated[list[UploadFile] | None, File()] = None,
    normal_changes: Annotated[list[UploadFile] | None, File()] = None,
    ecrs: Annotated[list[UploadFile] | None, File()] = None,
    problems: Annotated[list[UploadFile] | None, File()] = None,
    ritms: Annotated[list[UploadFile] | None, File()] = None,
):
    warnings: list[str] = []
    upload_map = {
        "incident": incidents,
        "standard_change": standard_changes,
        "normal_change": normal_changes,
        "ecr": ecrs,
        "problem": problems,
        "ritm": ritms,
    }
    frames = {kind: await _ingest(kind, uploads, warnings) for kind, uploads in upload_map.items()}
    if not frames["incident"]:
        message = "At least one valid Incident CSV/XLSX file is required."
        if warnings:
            message += " " + " | ".join(warnings)
        return templates.TemplateResponse(
            request=request, name="index.html", context={"error": message}, status_code=400
        )
    result = analyze(frames, warnings)
    analysis_id = _store(result)
    return templates.TemplateResponse(
        request=request,
        name="results.html",
        context={"result": result, "analysis_id": analysis_id},
    )


@app.get("/download/{analysis_id}/{format_name}")
async def download(analysis_id: str, format_name: str):
    result = RESULTS.get(analysis_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Analysis expired or was not found")
    if format_name == "xlsx":
        return Response(
            build_excel(result),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": 'attachment; filename="enterprise_service_analysis.xlsx"'},
        )
    if format_name == "docx":
        return Response(
            build_management_docx(result),
            media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            headers={"Content-Disposition": 'attachment; filename="management_summary.docx"'},
        )
    if format_name == "zip":
        stream = io.BytesIO()
        with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("enterprise_service_analysis.xlsx", build_excel(result))
            archive.writestr("management_summary.docx", build_management_docx(result))
        return Response(
            stream.getvalue(),
            media_type="application/zip",
            headers={"Content-Disposition": 'attachment; filename="enterprise_analysis_reports.zip"'},
        )
    raise HTTPException(status_code=400, detail="Supported formats: xlsx, docx, zip")
