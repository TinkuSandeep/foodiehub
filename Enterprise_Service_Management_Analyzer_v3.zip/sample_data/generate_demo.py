from pathlib import Path

import pandas as pd


OUT = Path(__file__).resolve().parent

incidents = pd.DataFrame([
    ["INC1001", "ODIN [CI1001]", "P2", "Closed", "2026-01-03 08:00", "2026-01-03 11:00", "Upstream badge file not received", "", "Yes"],
    ["INC1002", "ODIN [CI1001]", "P3", "Closed", "2026-02-03 08:00", "2026-02-03 10:30", "Upstream badge file not received", "", "No"],
    ["INC1003", "ODIN [CI1001]", "P2", "Open", "2026-03-03 08:00", "", "Upstream badge file not received", "", "Yes"],
    ["INC1004", "Lenel OnGuard [CI2001]", "P2", "Closed", "2026-04-10 09:00", "2026-04-10 13:00", "OpenAccess service unavailable after CHG2001", "CHG2001", "No"],
    ["INC1005", "EGSOP [CI3001]", "P3", "Closed", "2026-05-01 10:00", "2026-05-01 15:00", "Invalid data caused BigQuery extract failure", "", "No"],
], columns=["Number", "Application", "Priority", "State", "Opened at", "Closed at", "Short description", "Caused by Change", "SLA Breached"])

normal = pd.DataFrame([
    ["CHG2001", "Lenel OnGuard", "Closed", "2026-04-10 07:00", "OpenAccess configuration update", "Medium"],
], columns=["Number", "Application", "State", "Opened", "Short Description", "Risk"])

ecr = pd.DataFrame([
    ["CHG3001", "ODIN", "Closed", "2026-01-03 09:00", "Emergency restart of failed SSIS job"],
    ["CHG3002", "ODIN", "Closed", "2026-02-03 09:00", "Emergency restart of failed SSIS job"],
], columns=["Number", "Application", "State", "Opened", "Short Description"])

problems = pd.DataFrame([
    ["PRB1001", "Lenel OnGuard", "Open", "OpenAccess intermittent connection issue"],
], columns=["Number", "Application", "State", "Short Description"])

for name, frame in {"incidents": incidents, "normal_changes": normal, "ecrs": ecr, "problems": problems}.items():
    frame.to_excel(OUT / f"{name}.xlsx", index=False)

print(f"Demo files written to {OUT}")
