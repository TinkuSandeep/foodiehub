from __future__ import annotations

import io
import re
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pandas as pd
from rapidfuzz import fuzz


INCIDENT_ALIASES: dict[str, list[str]] = {
    "number": ["number", "incident", "incident number", "ticket", "ticket number", "task number"],
    "short_description": ["short description", "short_description", "summary", "title"],
    "description": ["description", "details", "work notes", "work_notes", "comments",
                    "additional comments", "close notes", "close_notes", "resolution notes"],
    "opened_at": ["opened", "opened at", "opened_at", "created", "created at",
                  "sys created on", "sys_created_on"],
    "closed_at": ["closed", "closed at", "closed_at", "resolved", "resolved at",
                  "resolved_at", "completed", "completed at"],
    "application": ["application", "business application", "business service",
                    "configuration item", "configuration_item", "config item", "ci",
                    "service", "application name", "app name"],
    "assignment_group": ["assignment group", "assignment_group", "support group", "group"],
    "state": ["state", "status", "incident state"],
    "priority": ["priority", "severity", "impact"],
    "category": ["category", "subcategory", "sub category"],
}

CHANGE_ALIASES: dict[str, list[str]] = {
    "number": ["number", "change", "change number", "change request", "standard change",
               "ticket", "task number"],
    "short_description": ["short description", "short_description", "summary", "title"],
    "description": ["description", "details", "work notes", "work_notes", "comments",
                    "close notes", "close_notes", "implementation plan", "implementation_plan",
                    "justification", "backout plan"],
    "opened_at": ["opened", "opened at", "opened_at", "created", "created at",
                  "sys created on", "sys_created_on", "planned start", "planned start date"],
    "closed_at": ["closed", "closed at", "closed_at", "completed", "completed at",
                  "planned end", "planned end date"],
    "application": ["application", "business application", "business service",
                    "configuration item", "configuration_item", "config item", "ci",
                    "service", "application name", "app name"],
    "assignment_group": ["assignment group", "assignment_group", "support group", "group"],
    "state": ["state", "status", "change state"],
    "priority": ["priority", "risk", "impact"],
    "category": ["category", "type", "change type", "model"],
}


CATEGORY_RULES: list[tuple[str, list[str]]] = [
    ("Upstream File Missing / Delayed", [
        "file not received", "file not available", "file unavailable", "missing file",
        "file missing", "late file", "file delayed", "delayed file", "awaiting file",
        "waiting for file", "source file", "upstream file", "input file", "inbound file",
    ]),
    ("File Data Quality / Format", [
        "corrupt file", "corrupted file", "invalid data", "bad data", "malformed",
        "extra character", "special character", "delimiter", "column mismatch",
        "missing column", "header mismatch", "record length", "field length",
        "value too long", "truncation", "data type mismatch", "invalid date",
        "duplicate record", "schema mismatch", "invalid format", "encoding",
    ]),
    ("File Transfer / Connectivity", [
        "sftp", "ftp", "file transfer", "transfer failed", "connection refused",
        "connection timeout", "network issue", "network failure", "permission denied",
        "access denied", "authentication failed", "path not found", "directory not found",
        "nas unavailable",
    ]),
    ("AutoSys / Scheduler", [
        "autosys", "autorep", "jil", "box job", "scheduler", "force start",
        "job status", "job failed", "batch failed", "restart job", "rerun", "re-run",
    ]),
    ("SSIS / ETL", [
        "ssis", "sql server integration services", "dtsx", "package execution",
        "package failed", "etl", "data load", "load failed",
    ]),
    ("Database", [
        "database", "sql", "oracle", "postgres", "db2", "deadlock",
        "constraint violation", "primary key", "foreign key", "insert failed",
        "stored procedure", "database unavailable", "table load",
    ]),
    ("Application / Code", [
        "application error", "code defect", "bug", "null pointer", "exception",
        "service unavailable", "api error", "deployment issue", "configuration issue",
        "config issue", "memory error", "out of memory",
    ]),
    ("Infrastructure / Server", [
        "server down", "host down", "cpu", "memory utilization", "disk space",
        "filesystem full", "service stopped", "windows service", "linux server",
        "infrastructure", "vm", "virtual machine",
    ]),
    ("Access / Security", [
        "access issue", "access denied", "permission", "authentication",
        "authorization", "password", "account locked", "certificate",
        "ssl", "tls", "security",
    ]),
    ("Monitoring / Alert", [
        "monitoring alert", "alert triggered", "threshold", "false alert",
        "health check", "heartbeat", "monitoring",
    ]),
    ("Business / Data Request", [
        "data request", "business request", "ad hoc", "report request",
        "extract request", "user request", "information request",
    ]),
]

PLATFORM_RULES: list[tuple[str, list[str]]] = [
    ("AutoSys", ["autosys", "autorep", "jil", "box job"]),
    ("SSIS", ["ssis", "dtsx", "sql server integration services"]),
    ("Database", ["oracle", "sql server", "postgres", "db2", "database"]),
    ("SFTP / File Transfer", ["sftp", "ftp", "file transfer", "nas path"]),
    ("Application / API", ["api", "application", "service", "microservice"]),
    ("Infrastructure", ["server", "host", "vm", "disk", "cpu", "memory"]),
]


@dataclass
class AnalysisResult:
    run_id: str
    incidents: pd.DataFrame
    changes: pd.DataFrame
    correlated: pd.DataFrame
    summary: dict[str, Any]
    output_dir: Path


def _norm(value: Any) -> str:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    value = str(value).strip().lower()
    value = re.sub(r"[_/\\\-]+", " ", value)
    return re.sub(r"\s+", " ", value)


def _text(value: Any) -> str:
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def _find_column(columns: list[str], aliases: list[str]) -> str | None:
    normalized = {_norm(c): c for c in columns}
    for alias in aliases:
        if _norm(alias) in normalized:
            return normalized[_norm(alias)]
    best, score = None, 0
    for alias in aliases:
        a = _norm(alias)
        for n, original in normalized.items():
            if a in n or n in a:
                current = min(len(a), len(n))
                if current > score:
                    best, score = original, current
    return best


def _all_text_columns(df: pd.DataFrame) -> list[str]:
    preferred = []
    patterns = (
        "description", "notes", "comments", "summary", "title", "details",
        "resolution", "close", "implementation", "justification", "category",
        "subcategory", "application", "service", "configuration item",
    )
    for col in df.columns:
        n = _norm(col)
        if any(p in n for p in patterns):
            preferred.append(col)
    return preferred


def read_excel_bytes(content: bytes) -> pd.DataFrame:
    if not content:
        raise ValueError("The uploaded Excel file is empty.")
    workbook = pd.ExcelFile(io.BytesIO(content))
    frames = []
    for sheet in workbook.sheet_names:
        df = pd.read_excel(workbook, sheet_name=sheet)
        df = df.dropna(how="all").dropna(axis=1, how="all")
        if not df.empty:
            frames.append(df)
    if not frames:
        raise ValueError("No usable data was found in the workbook.")
    return max(frames, key=lambda x: int(x.notna().sum().sum()))


def categorize(text: str) -> tuple[str, str, float]:
    normalized = _norm(text)
    matches: list[tuple[str, int, list[str]]] = []
    for category, terms in CATEGORY_RULES:
        found = [term for term in terms if term in normalized]
        if found:
            matches.append((category, len(found), found))
    if not matches:
        return "Other / Unclassified", "", 0.0
    matches.sort(key=lambda x: x[1], reverse=True)
    category, count, found = matches[0]
    confidence = min(100.0, 45.0 + count * 15.0)
    return category, ", ".join(found[:8]), confidence


def classify_platform(text: str) -> str:
    normalized = _norm(text)
    found = [name for name, terms in PLATFORM_RULES if any(t in normalized for t in terms)]
    if len(found) > 1:
        return " + ".join(found[:2])
    return found[0] if found else "Unknown"


def normalize_frame(df: pd.DataFrame, kind: str) -> pd.DataFrame:
    aliases = INCIDENT_ALIASES if kind == "incident" else CHANGE_ALIASES
    source = df.copy()
    source.columns = [str(c).strip() for c in source.columns]
    source = source.dropna(how="all").reset_index(drop=True)
    out = pd.DataFrame(index=source.index)

    for canonical, candidates in aliases.items():
        col = _find_column(list(source.columns), candidates)
        out[canonical] = source[col] if col else ""

    for col in ["number", "short_description", "description", "application",
                "assignment_group", "state", "priority", "category"]:
        out[col] = out[col].fillna("").astype(str).str.strip()

    out["opened_at"] = pd.to_datetime(out["opened_at"], errors="coerce", format="mixed")
    out["closed_at"] = pd.to_datetime(out["closed_at"], errors="coerce", format="mixed")

    missing = out["number"].eq("")
    prefix = "INC" if kind == "incident" else "CHG"
    out.loc[missing, "number"] = [f"{prefix}-ROW-{i+2}" for i in out.index[missing]]

    extra_text_cols = _all_text_columns(source)
    combined_extra = pd.Series("", index=source.index, dtype="object")
    for col in extra_text_cols:
        combined_extra = combined_extra.str.cat(
            source[col].fillna("").astype(str), sep=" "
        )

    out["combined_text"] = (
        out["short_description"] + " " + out["description"] + " " +
        out["application"] + " " + out["category"] + " " + combined_extra
    ).str.lower().str.replace(r"\s+", " ", regex=True).str.strip()

    classified = out["combined_text"].apply(categorize)
    out["analysis_category"] = classified.str[0]
    out["matched_keywords"] = classified.str[1]
    out["classification_confidence"] = classified.str[2]
    out["job_platform"] = out["combined_text"].apply(classify_platform)
    out["application_normalized"] = out["application"].replace("", "Unknown")

    duration = (out["closed_at"] - out["opened_at"]).dt.total_seconds() / 3600
    out["duration_hours"] = duration.where(duration >= 0).round(2)
    out["record_type"] = kind
    out["is_upstream_file_failure"] = out["analysis_category"].isin([
        "Upstream File Missing / Delayed",
        "File Data Quality / Format",
        "File Transfer / Connectivity",
    ])
    return out


def _score(inc: pd.Series, chg: pd.Series) -> float:
    i_text = _norm(f"{inc.get('short_description','')} {inc.get('description','')} "
                   f"{inc.get('application_normalized','')} {inc.get('analysis_category','')}")
    c_text = _norm(f"{chg.get('short_description','')} {chg.get('description','')} "
                   f"{chg.get('application_normalized','')} {chg.get('analysis_category','')}")
    score = float(fuzz.token_set_ratio(i_text, c_text))

    i_app, c_app = _norm(inc.get("application_normalized", "")), _norm(chg.get("application_normalized", ""))
    if i_app and c_app and i_app != "unknown" and i_app == c_app:
        score += 25
    if inc.get("analysis_category") == chg.get("analysis_category") and inc.get("analysis_category") != "Other / Unclassified":
        score += 18
    if inc.get("job_platform") == chg.get("job_platform") and inc.get("job_platform") != "Unknown":
        score += 10

    i_dt, c_dt = inc.get("opened_at"), chg.get("opened_at")
    if pd.notna(i_dt) and pd.notna(c_dt):
        hours = abs((c_dt - i_dt).total_seconds()) / 3600
        if hours <= 24:
            score += 20
        elif hours <= 72:
            score += 12
        elif hours <= 168:
            score += 6
        elif hours > 720:
            score -= 20
    return score


def correlate(incidents: pd.DataFrame, changes: pd.DataFrame, minimum_score: float = 45.0) -> pd.DataFrame:
    rows = []
    if incidents.empty:
        return pd.DataFrame()
    for _, inc in incidents.iterrows():
        best_score, best_change = 0.0, None
        for _, chg in changes.iterrows():
            s = _score(inc, chg)
            if s > best_score:
                best_score, best_change = s, chg
        matched = best_change is not None and best_score >= minimum_score
        rows.append({
            "incident_number": inc.get("number", ""),
            "incident_opened_at": inc.get("opened_at", pd.NaT),
            "incident_closed_at": inc.get("closed_at", pd.NaT),
            "application": inc.get("application_normalized", "Unknown"),
            "job_platform": inc.get("job_platform", "Unknown"),
            "analysis_category": inc.get("analysis_category", "Other / Unclassified"),
            "matched_keywords": inc.get("matched_keywords", ""),
            "classification_confidence": inc.get("classification_confidence", 0),
            "incident_summary": inc.get("short_description", ""),
            "change_number": best_change.get("number", "") if matched else "",
            "change_opened_at": best_change.get("opened_at", pd.NaT) if matched else pd.NaT,
            "change_state": best_change.get("state", "") if matched else "",
            "change_category": best_change.get("analysis_category", "") if matched else "",
            "correlation_score": round(best_score, 1) if matched else 0,
            "matched": matched,
            "manual_recovery_detected": matched,
            "resolution_hours": inc.get("duration_hours", pd.NA),
        })
    return pd.DataFrame(rows)


def build_summary(incidents: pd.DataFrame, changes: pd.DataFrame, correlated: pd.DataFrame) -> dict[str, Any]:
    matched = correlated[correlated["matched"] == True] if not correlated.empty else correlated
    hours = pd.to_numeric(incidents["duration_hours"], errors="coerce")
    valid_hours = hours[hours.notna() & (hours >= 0)]

    incident_categories = incidents["analysis_category"].value_counts().to_dict()
    change_categories = changes["analysis_category"].value_counts().to_dict()
    top_apps = incidents["application_normalized"].replace("", "Unknown").value_counts().head(10).to_dict()
    platforms = incidents["job_platform"].value_counts().to_dict()

    upstream_count = int(incidents["is_upstream_file_failure"].sum())
    total_incidents = len(incidents)
    matched_count = len(matched)

    monthly = {}
    opened = incidents.dropna(subset=["opened_at"]).copy()
    if not opened.empty:
        monthly = opened.assign(month=opened["opened_at"].dt.strftime("%Y-%m"))["month"].value_counts().sort_index().to_dict()

    return {
        "total_incidents_uploaded": int(total_incidents),
        "total_changes_uploaded": int(len(changes)),
        "categorized_incidents": int((incidents["analysis_category"] != "Other / Unclassified").sum()),
        "categorized_changes": int((changes["analysis_category"] != "Other / Unclassified").sum()),
        "upstream_file_incidents": upstream_count,
        "correlated_standard_changes": int(matched_count),
        "unmatched_upstream_incidents": int(max(total_incidents - matched_count, 0)),
        "average_resolution_hours": round(float(valid_hours.mean()), 2) if not valid_hours.empty else 0,
        "median_resolution_hours": round(float(valid_hours.median()), 2) if not valid_hours.empty else 0,
        "estimated_manual_effort_hours": round((total_incidents * 30 + matched_count * 20) / 60, 1),
        "automation_opportunity_pct": round(matched_count / total_incidents * 100, 1) if total_incidents else 0,
        "incident_category_distribution": incident_categories,
        "change_category_distribution": change_categories,
        "root_cause_distribution": incident_categories,
        "top_applications": top_apps,
        "platform_distribution": platforms,
        "monthly_trend": monthly,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }


def analyze(incident_bytes: bytes, change_bytes: bytes, base_output: Path) -> AnalysisResult:
    run_id = uuid.uuid4().hex[:10]
    output_dir = base_output / run_id
    output_dir.mkdir(parents=True, exist_ok=True)

    incidents = normalize_frame(read_excel_bytes(incident_bytes), "incident")
    changes = normalize_frame(read_excel_bytes(change_bytes), "change")
    correlated = correlate(incidents, changes)
    summary = build_summary(incidents, changes, correlated)

    incidents.to_csv(output_dir / "normalized_incidents.csv", index=False, encoding="utf-8-sig")
    changes.to_csv(output_dir / "normalized_changes.csv", index=False, encoding="utf-8-sig")
    correlated.to_csv(output_dir / "correlated_cases.csv", index=False, encoding="utf-8-sig")

    return AnalysisResult(run_id, incidents, changes, correlated, summary, output_dir)
