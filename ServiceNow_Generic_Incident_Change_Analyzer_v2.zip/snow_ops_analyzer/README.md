# ServiceNow Upstream Failure Analyzer

A FastAPI web application that analyzes ServiceNow incident and standard-change Excel exports to identify upstream file delays, failed AutoSys/SSIS jobs, correlated recovery changes, resolution time, repeated applications, and estimated manual effort.

## Run on Windows
1. Install Python 3.11 or newer.
2. Extract the project.
3. Double-click `run.bat` or run it from Command Prompt.
4. Open `http://localhost:8000`.

## Input
Upload two Excel files:
- Incident export
- Standard change export

The application automatically maps common column names. Recommended fields are Number, Short Description, Description/Work Notes, Opened At, Closed At, Application/Business Service, Assignment Group, and State.

## Outputs
- Interactive browser summary
- Correlated case CSV
- Management Excel workbook
- Word management summary
- PDF summary

## Classification logic
A record is considered an upstream-file incident when its text includes at least one upstream/file-delay indicator and at least one job indicator such as AutoSys, SSIS, batch, job failure, rerun, or restart.

## Production enhancements
- Add authentication and role-based access.
- Store runs in SQL Server rather than process memory.
- Integrate ServiceNow REST APIs.
- Add Outlook ingestion through Microsoft Graph or a controlled Windows service account.
- Replace keyword classification with an approved internal LLM endpoint.
- Add application-specific file schedules and recovery runbooks.
