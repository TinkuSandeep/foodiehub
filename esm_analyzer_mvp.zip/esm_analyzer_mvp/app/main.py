from __future__ import annotations
from pathlib import Path
from uuid import uuid4
import shutil
import pandas as pd
from fastapi import FastAPI, Request, UploadFile, File, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse, FileResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.config import settings, BASE_DIR
from app.db import init_db, SessionLocal, UploadBatch
from app.services.storage import process_excel, load_all_data, clear_data
from app.services.analytics import filter_data, build_summary
from app.services.insights import generate_insights
from app.services.exports import export_excel, export_ppt, export_pdf

app = FastAPI(title=settings.app_name, version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "app" / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "app" / "templates")

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.on_event("startup")
def startup() -> None:
    init_db()

@app.get("/", response_class=HTMLResponse)
def dashboard(
    request: Request,
    application: str = Query("All"),
    month: str = Query("All"),
):
    df = load_all_data()
    applications = ["All"]
    months = ["All"]
    if not df.empty:
        applications += sorted(df["application"].dropna().astype(str).unique().tolist())
        parsed_months = pd.to_datetime(df["opened_at"], errors="coerce").dt.to_period("M").dropna().astype(str)
        months += sorted(parsed_months.unique().tolist(), reverse=True)

    filtered = filter_data(df, application, month)
    summary = build_summary(filtered)
    insights = generate_insights(summary)
    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "summary": summary,
        "insights": insights,
        "applications": applications,
        "months": months,
        "selected_application": application,
        "selected_month": month,
    })

@app.get("/upload", response_class=HTMLResponse)
def upload_page(request: Request, db: Session = Depends(get_db)):
    uploads = db.query(UploadBatch).order_by(UploadBatch.uploaded_at.desc()).limit(100).all()
    return templates.TemplateResponse("upload.html", {"request": request, "uploads": uploads})

@app.post("/upload")
async def upload_files(request: Request, files: list[UploadFile] = File(...), db: Session = Depends(get_db)):
    all_results = []
    errors = []
    for upload in files:
        suffix = Path(upload.filename or "").suffix.lower()
        if suffix not in {".xlsx", ".xlsm"}:
            errors.append(f"{upload.filename}: unsupported file type")
            continue

        target = settings.upload_dir / f"{uuid4().hex}_{Path(upload.filename).name}"
        with target.open("wb") as buffer:
            shutil.copyfileobj(upload.file, buffer)

        if target.stat().st_size > settings.max_upload_mb * 1024 * 1024:
            target.unlink(missing_ok=True)
            errors.append(f"{upload.filename}: file exceeds {settings.max_upload_mb} MB")
            continue

        try:
            results = process_excel(target, upload.filename or target.name, db)
            all_results.extend(results)
        except Exception as exc:
            errors.append(f"{upload.filename}: {exc}")
        finally:
            target.unlink(missing_ok=True)

    return templates.TemplateResponse("upload_result.html", {
        "request": request,
        "results": all_results,
        "errors": errors,
    })

@app.post("/data/clear")
def clear_all(db: Session = Depends(get_db)):
    clear_data(db)
    return RedirectResponse(url="/upload", status_code=303)

@app.get("/api/summary")
def api_summary(application: str = "All", month: str = "All"):
    df = filter_data(load_all_data(), application, month)
    summary = build_summary(df)
    return {"summary": summary, "insights": generate_insights(summary)}

@app.get("/export/{format_name}")
def export_report(format_name: str, application: str = "All", month: str = "All"):
    df = filter_data(load_all_data(), application, month)
    if df.empty:
        raise HTTPException(status_code=404, detail="No data is available for the selected filters.")
    summary = build_summary(df)
    safe_app = "".join(c if c.isalnum() or c in "-_" else "_" for c in application)
    safe_month = "".join(c if c.isalnum() or c in "-_" else "_" for c in month)

    if format_name == "excel":
        path = export_excel(df, summary, safe_app, safe_month)
    elif format_name == "ppt":
        path = export_ppt(summary, safe_app, safe_month)
    elif format_name == "pdf":
        path = export_pdf(summary, safe_app, safe_month)
    else:
        raise HTTPException(status_code=400, detail="Format must be excel, ppt, or pdf.")
    return FileResponse(path, filename=path.name)

@app.get("/health")
def health():
    return {"status": "ok", "application": settings.app_name}
