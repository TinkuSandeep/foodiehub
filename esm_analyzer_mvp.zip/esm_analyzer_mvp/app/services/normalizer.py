from __future__ import annotations
from pathlib import Path
import re
import pandas as pd

ALIASES = {
    "number": ["number", "ticket number", "incident number", "change number", "problem number", "ritm number", "requested item"],
    "application": ["application", "business application", "application name", "service", "service offering", "business service"],
    "opened_at": ["opened", "opened at", "created", "created at", "request date", "start date"],
    "closed_at": ["closed", "closed at", "resolved", "resolved at", "end date", "actual end"],
    "priority": ["priority", "severity", "impact priority"],
    "state": ["state", "status", "ticket status", "change state"],
    "assignment_group": ["assignment group", "resolver group", "assigned group", "support group"],
    "assigned_to": ["assigned to", "resolver", "owner"],
    "short_description": ["short description", "summary", "title", "description"],
    "description": ["description", "work notes", "comments", "close notes", "resolution notes"],
    "category": ["category", "issue category", "request category"],
    "subcategory": ["subcategory", "sub category"],
    "configuration_item": ["configuration item", "ci", "configuration item name"],
    "close_code": ["close code", "resolution code", "closure code"],
    "sla_breached": ["sla breached", "breached", "made sla", "sla status"],
    "reopened": ["reopened", "reopen count"],
    "change_type": ["change type", "type", "change model"],
    "risk": ["risk", "risk level"],
    "success": ["successful", "success", "implementation result", "closure status"],
    "caused_by_change": ["caused by change", "change caused"],
    "problem": ["problem", "parent problem", "problem id"],
    "catalog_item": ["catalog item", "item", "request item", "requested item name"],
    "approval": ["approval", "approval status"],
    "due_date": ["due date", "sla due", "target date"],
}

CANONICAL_COLUMNS = list(ALIASES.keys()) + ["ticket_type", "source_file"]

def clean_column(value: str) -> str:
    value = str(value).strip().lower()
    value = re.sub(r"[_/\\-]+", " ", value)
    value = re.sub(r"[^a-z0-9 ]+", "", value)
    return re.sub(r"\\s+", " ", value).strip()

def _find_column(columns: list[str], aliases: list[str]) -> str | None:
    normalized = {clean_column(c): c for c in columns}
    for alias in aliases:
        if clean_column(alias) in normalized:
            return normalized[clean_column(alias)]
    for alias in aliases:
        a = clean_column(alias)
        for cleaned, original in normalized.items():
            if a in cleaned or cleaned in a:
                return original
    return None

def detect_ticket_type(df: pd.DataFrame, filename: str) -> str:
    haystack = " ".join(clean_column(c) for c in df.columns) + " " + clean_column(filename)
    number_values = ""
    for col in df.columns:
        if "number" in clean_column(col):
            number_values += " " + " ".join(df[col].dropna().astype(str).head(25).tolist())

    combined = (haystack + " " + number_values).lower()
    if re.search(r"\\britm\\d+", combined) or "catalog item" in combined or "requested item" in combined:
        return "ritm"
    if re.search(r"\\bprb\\d+", combined) or "problem" in combined:
        return "problem"
    if re.search(r"\\bchg\\d+", combined) or "change type" in combined or "change model" in combined:
        return "change"
    if re.search(r"\\binc\\d+", combined) or "incident" in combined:
        return "incident"
    return "unknown"

def normalize_dataframe(df: pd.DataFrame, filename: str) -> tuple[pd.DataFrame, str, list[str]]:
    ticket_type = detect_ticket_type(df, filename)
    warnings: list[str] = []
    output = pd.DataFrame(index=df.index)

    for canonical, aliases in ALIASES.items():
        source = _find_column(list(df.columns), aliases)
        output[canonical] = df[source] if source else None

    output["ticket_type"] = ticket_type
    output["source_file"] = filename

    for col in ("opened_at", "closed_at", "due_date"):
        output[col] = pd.to_datetime(output[col], errors="coerce")

    output["number"] = output["number"].astype("string").str.strip()
    output["application"] = (
        output["application"]
        .astype("string")
        .replace({"<NA>": "Unknown", "nan": "Unknown", "None": "Unknown"})
        .fillna("Unknown")
        .str.strip()
    )
    output["priority"] = output["priority"].astype("string").str.upper().str.strip()
    output["state"] = output["state"].astype("string").str.strip()
    output["short_description"] = output["short_description"].astype("string").fillna("")
    output["description"] = output["description"].astype("string").fillna("")
    output["text_blob"] = (output["short_description"] + " " + output["description"]).str.lower()

    if output["number"].isna().all():
        warnings.append("Ticket number column was not detected.")
    if output["application"].eq("Unknown").all():
        warnings.append("Application column was not detected.")
    if output["opened_at"].isna().all():
        warnings.append("Opened/created date column was not detected.")
    if ticket_type == "unknown":
        warnings.append("Ticket type could not be detected; file retained as unknown.")

    return output, ticket_type, warnings

def read_excel_all_sheets(path: Path) -> list[tuple[str, pd.DataFrame]]:
    workbook = pd.ExcelFile(path)
    result = []
    for sheet in workbook.sheet_names:
        df = pd.read_excel(path, sheet_name=sheet)
        if not df.empty:
            result.append((sheet, df))
    return result
