from __future__ import annotations
from pathlib import Path
from uuid import uuid4
import pandas as pd
from sqlalchemy.orm import Session
from app.config import settings
from app.db import UploadBatch
from app.models import UploadResult
from app.services.normalizer import normalize_dataframe, read_excel_all_sheets

ALLOWED_EXTENSIONS = {".xlsx", ".xlsm"}

def process_excel(path: Path, original_filename: str, db: Session) -> list[UploadResult]:
    if path.suffix.lower() not in ALLOWED_EXTENSIONS:
        raise ValueError("Only .xlsx and .xlsm files are supported.")

    results: list[UploadResult] = []
    for sheet_name, raw in read_excel_all_sheets(path):
        normalized, ticket_type, warnings = normalize_dataframe(raw, original_filename)
        unique_name = f"{uuid4().hex}_{ticket_type}_{sheet_name}.csv"
        normalized_path = settings.normalized_dir / unique_name
        normalized.to_csv(normalized_path, index=False)

        applications = sorted(
            a for a in normalized["application"].dropna().astype(str).unique().tolist()
            if a and a.lower() not in {"nan", "none", "<na>"}
        )
        record = UploadBatch(
            filename=f"{original_filename} [{sheet_name}]",
            ticket_type=ticket_type,
            row_count=len(normalized),
            applications="|".join(applications),
            normalized_file=str(normalized_path),
        )
        db.add(record)
        db.commit()

        results.append(
            UploadResult(
                filename=f"{original_filename} [{sheet_name}]",
                ticket_type=ticket_type,
                row_count=len(normalized),
                applications=applications,
                warnings=warnings,
                normalized_file=str(normalized_path),
            )
        )
    return results

def load_all_data() -> pd.DataFrame:
    files = sorted(settings.normalized_dir.glob("*.csv"))
    frames = []
    for file in files:
        try:
            frame = pd.read_csv(file, parse_dates=["opened_at", "closed_at", "due_date"], low_memory=False)
            frames.append(frame)
        except Exception:
            continue
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)

def clear_data(db: Session) -> None:
    for file in settings.normalized_dir.glob("*.csv"):
        file.unlink(missing_ok=True)
    db.query(UploadBatch).delete()
    db.commit()
