from __future__ import annotations
import math
import pandas as pd
import numpy as np

CATEGORY_PATTERNS = {
    "Upstream": r"upstream|file delay|late file|missing file|invalid file|bad data|extra character|column size",
    "Database": r"database|oracle|sql server|postgres|db |deadlock|blocking|listener",
    "Network": r"network|dns|firewall|latency|timeout|connection reset",
    "Authentication": r"authentication|login|password|credential|unauthorized|401|access denied",
    "Infrastructure": r"server|vm |cpu|memory|disk|storage|filesystem|host",
    "Application": r"application|service unavailable|500|exception|bug|code defect|api failure",
    "Vendor": r"vendor|third party|cots|supplier",
    "Batch/Job": r"autosys|ssis|batch|job failed|scheduler",
    "Certificate": r"certificate|ssl|tls|expired cert",
}

def _safe_int(value) -> int:
    try:
        if pd.isna(value):
            return 0
        return int(value)
    except Exception:
        return 0

def filter_data(df: pd.DataFrame, application: str | None = None, month: str | None = None) -> pd.DataFrame:
    if df.empty:
        return df
    result = df.copy()
    if application and application != "All":
        result = result[result["application"].astype(str).str.casefold() == application.casefold()]
    if month and month != "All":
        period = pd.to_datetime(result["opened_at"], errors="coerce").dt.to_period("M").astype(str)
        result = result[period == month]
    return result

def classify_text(series: pd.Series) -> pd.Series:
    result = pd.Series("Other", index=series.index, dtype="object")
    for category, pattern in CATEGORY_PATTERNS.items():
        mask = series.fillna("").str.contains(pattern, case=False, regex=True)
        result = result.mask(mask & result.eq("Other"), category)
    return result

def calculate_mttr_hours(df: pd.DataFrame) -> float:
    if df.empty:
        return 0.0
    opened = pd.to_datetime(df["opened_at"], errors="coerce")
    closed = pd.to_datetime(df["closed_at"], errors="coerce")
    hours = (closed - opened).dt.total_seconds() / 3600
    hours = hours[(hours >= 0) & (hours < 24 * 365)]
    return round(float(hours.mean()), 2) if not hours.empty else 0.0

def _sla_breach_count(df: pd.DataFrame) -> int:
    if df.empty:
        return 0
    values = df["sla_breached"].astype(str).str.lower().str.strip()
    breached = values.isin({"true", "yes", "y", "1", "breached", "missed", "false"})
    # "Made SLA = false" is a breach; direct "SLA breached = false" is not.
    direct_false = values.eq("false")
    header_context_unknown = True
    # Conservative behavior: count explicit breach words and false only when source maps from made-SLA exports.
    explicit = values.str.contains("breach|miss", regex=True)
    return int((explicit | direct_false).sum())

def build_summary(df: pd.DataFrame) -> dict:
    if df.empty:
        return empty_summary()

    typed = {t: df[df["ticket_type"] == t].copy() for t in ("incident", "change", "problem", "ritm")}
    inc = typed["incident"]
    chg = typed["change"]
    prb = typed["problem"]
    ritm = typed["ritm"]

    priority = inc["priority"].fillna("Unknown").astype(str).str.upper().value_counts().to_dict()
    states = df["state"].fillna("Unknown").astype(str).value_counts().head(10).to_dict()

    inc_categories = classify_text(inc["text_blob"]) if not inc.empty else pd.Series(dtype=str)
    categories = inc_categories.value_counts().to_dict()

    monthly = (
        df.assign(month=pd.to_datetime(df["opened_at"], errors="coerce").dt.to_period("M").astype(str))
        .query("month != 'NaT'")
        .groupby(["month", "ticket_type"])
        .size()
        .unstack(fill_value=0)
        .sort_index()
    )
    monthly_records = monthly.reset_index().to_dict(orient="records") if not monthly.empty else []

    app_counts = df["application"].fillna("Unknown").astype(str).value_counts().head(15).to_dict()
    assignment_groups = inc["assignment_group"].fillna("Unknown").astype(str).value_counts().head(10).to_dict()
    cis = inc["configuration_item"].fillna("Unknown").astype(str).value_counts().head(10).to_dict()

    change_type = chg["change_type"].fillna("Unknown").astype(str).str.lower()
    emergency_changes = int(change_type.str.contains("emergency|ecr", regex=True).sum())
    successful_changes = int(
        chg["success"].fillna("").astype(str).str.lower().str.contains("success|implemented|complete").sum()
    )
    if successful_changes == 0:
        successful_changes = int(
            chg["state"].fillna("").astype(str).str.lower().str.contains("closed|complete|implemented").sum()
        )
    change_success_rate = round(successful_changes / len(chg) * 100, 1) if len(chg) else 0.0

    open_problem_mask = ~prb["state"].fillna("").astype(str).str.lower().str.contains("closed|resolved|cancel")
    open_ritm_mask = ~ritm["state"].fillna("").astype(str).str.lower().str.contains("closed|complete|cancel|reject")

    return {
        "totals": {
            "all": len(df),
            "incidents": len(inc),
            "changes": len(chg),
            "problems": len(prb),
            "ritms": len(ritm),
        },
        "incident": {
            "mttr_hours": calculate_mttr_hours(inc),
            "sla_breaches": _sla_breach_count(inc),
            "reopened": int(pd.to_numeric(inc["reopened"], errors="coerce").fillna(0).gt(0).sum()),
            "priority": priority,
            "categories": categories,
            "assignment_groups": assignment_groups,
            "configuration_items": cis,
        },
        "change": {
            "emergency": emergency_changes,
            "success_rate": change_success_rate,
            "successful": successful_changes,
        },
        "problem": {
            "open": int(open_problem_mask.sum()),
        },
        "ritm": {
            "open": int(open_ritm_mask.sum()),
        },
        "states": states,
        "monthly": monthly_records,
        "applications": app_counts,
    }

def empty_summary() -> dict:
    return {
        "totals": {"all": 0, "incidents": 0, "changes": 0, "problems": 0, "ritms": 0},
        "incident": {
            "mttr_hours": 0,
            "sla_breaches": 0,
            "reopened": 0,
            "priority": {},
            "categories": {},
            "assignment_groups": {},
            "configuration_items": {},
        },
        "change": {"emergency": 0, "success_rate": 0, "successful": 0},
        "problem": {"open": 0},
        "ritm": {"open": 0},
        "states": {},
        "monthly": [],
        "applications": {},
    }

def previous_month_change(df: pd.DataFrame, ticket_type: str = "incident") -> float | None:
    subset = df[df["ticket_type"] == ticket_type].copy()
    if subset.empty:
        return None
    subset["month"] = pd.to_datetime(subset["opened_at"], errors="coerce").dt.to_period("M")
    counts = subset.groupby("month").size().sort_index()
    if len(counts) < 2:
        return None
    previous, current = counts.iloc[-2], counts.iloc[-1]
    if previous == 0:
        return None
    return round((current - previous) / previous * 100, 1)
