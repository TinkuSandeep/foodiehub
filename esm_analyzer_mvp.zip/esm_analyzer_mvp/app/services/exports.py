from __future__ import annotations
from datetime import datetime
from pathlib import Path
import pandas as pd
from openpyxl.styles import Font, PatternFill, Alignment
from pptx import Presentation
from pptx.util import Inches, Pt
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from app.config import settings
from app.services.insights import generate_insights

def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def export_excel(df: pd.DataFrame, summary: dict, application: str, month: str) -> Path:
    path = settings.export_dir / f"ESM_MBR_{application}_{month}_{_timestamp()}.xlsx"
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        overview = pd.DataFrame([
            ["Application", application],
            ["Reporting Month", month],
            ["Total Records", summary["totals"]["all"]],
            ["Incidents", summary["totals"]["incidents"]],
            ["Changes", summary["totals"]["changes"]],
            ["Problems", summary["totals"]["problems"]],
            ["RITMs", summary["totals"]["ritms"]],
            ["Incident MTTR (hours)", summary["incident"]["mttr_hours"]],
            ["SLA Breaches", summary["incident"]["sla_breaches"]],
            ["Emergency Changes", summary["change"]["emergency"]],
            ["Change Success Rate", summary["change"]["success_rate"]],
            ["Open Problems", summary["problem"]["open"]],
            ["Open RITMs", summary["ritm"]["open"]],
        ], columns=["Metric", "Value"])
        overview.to_excel(writer, sheet_name="Executive Summary", index=False)

        for ticket_type in ("incident", "change", "problem", "ritm"):
            subset = df[df["ticket_type"] == ticket_type].copy()
            subset.drop(columns=["text_blob"], errors="ignore").to_excel(
                writer, sheet_name=ticket_type.title()[:31], index=False
            )

        pd.DataFrame(list(summary["incident"]["priority"].items()), columns=["Priority", "Count"]).to_excel(
            writer, sheet_name="Incident Priority", index=False
        )
        pd.DataFrame(list(summary["incident"]["categories"].items()), columns=["Category", "Count"]).to_excel(
            writer, sheet_name="Incident Categories", index=False
        )
        pd.DataFrame(summary["monthly"]).to_excel(writer, sheet_name="Monthly Trend", index=False)

        wb = writer.book
        for ws in wb.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F4E78")
                cell.alignment = Alignment(horizontal="center")
            for column_cells in ws.columns:
                max_len = min(max(len(str(c.value or "")) for c in column_cells) + 2, 50)
                ws.column_dimensions[column_cells[0].column_letter].width = max_len
    return path

def export_ppt(summary: dict, application: str, month: str) -> Path:
    path = settings.export_dir / f"ESM_MBR_{application}_{month}_{_timestamp()}.pptx"
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    def title_slide(title: str, subtitle: str):
        slide = prs.slides.add_slide(prs.slide_layouts[0])
        slide.shapes.title.text = title
        slide.placeholders[1].text = subtitle

    def bullet_slide(title: str, bullets: list[str]):
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        slide.shapes.title.text = title
        tf = slide.placeholders[1].text_frame
        tf.clear()
        for i, bullet in enumerate(bullets):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = bullet
            p.font.size = Pt(22)

    title_slide("Enterprise Service Management MBR", f"{application} | {month}")

    t = summary["totals"]
    bullet_slide("Executive Summary", [
        f"Total records: {t['all']}",
        f"Incidents: {t['incidents']} | Changes: {t['changes']}",
        f"Problems: {t['problems']} | RITMs: {t['ritms']}",
        f"Incident MTTR: {summary['incident']['mttr_hours']} hours",
        f"Change success rate: {summary['change']['success_rate']}%",
    ])

    top_priorities = [f"{k}: {v}" for k, v in list(summary["incident"]["priority"].items())[:6]] or ["No priority data"]
    bullet_slide("Incident Priority Distribution", top_priorities)

    top_categories = [f"{k}: {v}" for k, v in list(summary["incident"]["categories"].items())[:6]] or ["No classified incident data"]
    bullet_slide("Primary Incident Drivers", top_categories)

    bullet_slide("Change and Problem Management", [
        f"Emergency changes: {summary['change']['emergency']}",
        f"Successful changes detected: {summary['change']['successful']}",
        f"Open problems: {summary['problem']['open']}",
        f"Open requested items: {summary['ritm']['open']}",
    ])

    insights = generate_insights(summary)
    bullet_slide("Risks and Recommendations", [f"{x['title']}: {x['message']}" for x in insights])

    prs.save(path)
    return path

def export_pdf(summary: dict, application: str, month: str) -> Path:
    path = settings.export_dir / f"ESM_Executive_Report_{application}_{month}_{_timestamp()}.pdf"
    styles = getSampleStyleSheet()
    doc = SimpleDocTemplate(str(path), pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
    story = [
        Paragraph("Enterprise Service Management Executive Report", styles["Title"]),
        Paragraph(f"Application: {application} &nbsp;&nbsp; Reporting period: {month}", styles["Heading2"]),
        Spacer(1, 12),
    ]
    rows = [["Metric", "Value"]]
    rows += [
        ["Total records", summary["totals"]["all"]],
        ["Incidents", summary["totals"]["incidents"]],
        ["Changes", summary["totals"]["changes"]],
        ["Problems", summary["totals"]["problems"]],
        ["RITMs", summary["totals"]["ritms"]],
        ["Incident MTTR (hours)", summary["incident"]["mttr_hours"]],
        ["SLA breaches", summary["incident"]["sla_breaches"]],
        ["Emergency changes", summary["change"]["emergency"]],
        ["Change success rate", f"{summary['change']['success_rate']}%"],
        ["Open problems", summary["problem"]["open"]],
    ]
    table = Table(rows, colWidths=[250, 180])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#1F4E78")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F2F6FA")]),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
        ("PADDING", (0,0), (-1,-1), 7),
    ]))
    story += [table, Spacer(1, 18), Paragraph("Insights and Recommendations", styles["Heading2"])]
    for item in generate_insights(summary):
        story.append(Paragraph(f"<b>{item['title']}</b>: {item['message']}", styles["BodyText"]))
        story.append(Spacer(1, 6))
    doc.build(story)
    return path
