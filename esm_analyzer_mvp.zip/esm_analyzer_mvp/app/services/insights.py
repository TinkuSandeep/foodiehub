from __future__ import annotations

def generate_insights(summary: dict) -> list[dict]:
    insights: list[dict] = []
    totals = summary["totals"]
    incident = summary["incident"]
    change = summary["change"]

    if totals["all"] == 0:
        return [{"severity": "info", "title": "No data", "message": "Upload ServiceNow Excel exports to begin analysis."}]

    if incident["sla_breaches"] > 0:
        insights.append({
            "severity": "critical",
            "title": "SLA exposure",
            "message": f"{incident['sla_breaches']} incidents appear to have breached SLA. Review priority, ownership, and ageing.",
        })

    if incident["mttr_hours"] > 24:
        insights.append({
            "severity": "warning",
            "title": "High MTTR",
            "message": f"Average incident resolution time is {incident['mttr_hours']} hours. Investigate handoffs and repeat failure patterns.",
        })

    categories = incident.get("categories", {})
    if categories:
        top_category = max(categories, key=categories.get)
        top_count = categories[top_category]
        insights.append({
            "severity": "info",
            "title": "Primary incident driver",
            "message": f"{top_category} is the largest classified incident category with {top_count} tickets.",
        })

    if totals["changes"] and change["success_rate"] < 90:
        insights.append({
            "severity": "warning",
            "title": "Change reliability",
            "message": f"Detected change success rate is {change['success_rate']}%. Validate implementation outcomes and rollback causes.",
        })

    if summary["problem"]["open"] > 0:
        insights.append({
            "severity": "info",
            "title": "Problem backlog",
            "message": f"{summary['problem']['open']} problem records remain open. Prioritize items linked to repeat incidents.",
        })

    if summary["ritm"]["open"] > 0:
        insights.append({
            "severity": "info",
            "title": "Request backlog",
            "message": f"{summary['ritm']['open']} requested items appear open or pending.",
        })

    if not insights:
        insights.append({
            "severity": "success",
            "title": "Stable reporting period",
            "message": "No major threshold-based risks were detected in the uploaded data.",
        })
    return insights
