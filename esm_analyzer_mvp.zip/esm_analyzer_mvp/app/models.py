from dataclasses import dataclass
from typing import Any

@dataclass
class UploadResult:
    filename: str
    ticket_type: str
    row_count: int
    applications: list[str]
    warnings: list[str]
    normalized_file: str

@dataclass
class DashboardFilters:
    application: str | None = None
    month: str | None = None

@dataclass
class MetricCard:
    name: str
    value: Any
    change: str | None = None
