from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "Enterprise Service Management Analyzer"
    data_dir: Path = BASE_DIR / "data"
    upload_dir: Path = BASE_DIR / "data" / "uploads"
    normalized_dir: Path = BASE_DIR / "data" / "normalized"
    export_dir: Path = BASE_DIR / "data" / "exports"
    database_url: str = f"sqlite:///{BASE_DIR / 'data' / 'esm.db'}"
    max_upload_mb: int = 50
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
for directory in (
    settings.data_dir,
    settings.upload_dir,
    settings.normalized_dir,
    settings.export_dir,
):
    directory.mkdir(parents=True, exist_ok=True)
