from pathlib import Path
from datetime import datetime, timedelta
import random
import pandas as pd

random.seed(7)
out = Path(__file__).resolve().parent.parent / "sample_data"
out.mkdir(exist_ok=True)

apps = ["ODIN", "Lenel", "CCDMS"]
priorities = ["P2", "P3", "P3", "P4"]
groups = ["App Support", "Database Support", "Middleware", "Network"]
incident_texts = [
    "Upstream file arrived late and Autosys job failed",
    "Invalid data with extra character caused SSIS package failure",
    "Database listener connection timeout",
    "API returned 500 internal server error",
    "Authentication failed with HTTP 401",
    "Disk space threshold reached on application server",
]

rows = []
start = datetime(2026, 1, 1)
for i in range(240):
    opened = start + timedelta(days=random.randint(0, 180), hours=random.randint(0, 23))
    duration = timedelta(hours=random.randint(1, 72))
    rows.append({
        "Number": f"INC{100000+i}",
        "Business Application": random.choice(apps),
        "Opened At": opened,
        "Closed At": opened + duration,
        "Priority": random.choice(priorities),
        "State": "Closed",
        "Assignment Group": random.choice(groups),
        "Short Description": random.choice(incident_texts),
        "Configuration Item": random.choice(["odin-api", "lenel-app", "sql-prod", "autosys-job"]),
        "SLA Breached": random.choice(["No", "No", "No", "Yes"]),
        "Reopen Count": random.choice([0, 0, 0, 1]),
    })
pd.DataFrame(rows).to_excel(out / "incidents.xlsx", index=False)

changes = []
for i in range(80):
    opened = start + timedelta(days=random.randint(0, 180))
    ctype = random.choice(["Standard", "Normal", "Emergency"])
    changes.append({
        "Number": f"CHG{200000+i}",
        "Application": random.choice(apps),
        "Opened": opened,
        "Closed": opened + timedelta(hours=random.randint(2, 24)),
        "Change Type": ctype,
        "State": random.choice(["Closed Complete", "Closed Complete", "Cancelled"]),
        "Implementation Result": random.choice(["Successful", "Successful", "Failed"]),
        "Risk": random.choice(["Low", "Medium", "High"]),
        "Short Description": random.choice(["Weekly service restart", "Certificate renewal", "Emergency database recovery"]),
    })
pd.DataFrame(changes).to_excel(out / "changes.xlsx", index=False)

problems = []
for i in range(25):
    opened = start + timedelta(days=random.randint(0, 180))
    problems.append({
        "Number": f"PRB{300000+i}",
        "Application": random.choice(apps),
        "Opened": opened,
        "State": random.choice(["Open", "Known Error", "Closed"]),
        "Short Description": random.choice(["Repeat upstream delay", "Recurring database connection issue", "Intermittent API failure"]),
    })
pd.DataFrame(problems).to_excel(out / "problems.xlsx", index=False)

ritms = []
for i in range(100):
    opened = start + timedelta(days=random.randint(0, 180))
    ritms.append({
        "Number": f"RITM{400000+i}",
        "Application": random.choice(apps),
        "Created": opened,
        "Closed": opened + timedelta(days=random.randint(1, 10)),
        "State": random.choice(["Closed Complete", "Work in Progress", "Pending Approval"]),
        "Catalog Item": random.choice(["Application Access", "Software Installation", "Service Request"]),
        "Approval": random.choice(["Approved", "Requested"]),
    })
pd.DataFrame(ritms).to_excel(out / "ritms.xlsx", index=False)

print(f"Sample files created in {out}")
