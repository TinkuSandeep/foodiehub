# Enterprise Service Management Analyzer MVP

A local, production-oriented FastAPI application for monthly MBR analysis using ServiceNow Excel exports.

## Included modules

- Multi-file Excel upload
- Automatic ticket-type detection
- Column-name normalization
- Incident analysis
- Standard/Normal/Emergency Change analysis
- Problem analysis
- RITM analysis
- Application and reporting-period filtering
- KPI dashboard
- Monthly and priority charts
- Executive insights
- Excel export
- PowerPoint MBR export
- PDF executive report
- SQLite metadata storage
- Sample-data generator
- Basic tests

## Quick start

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python scripts/generate_sample_data.py
uvicorn app.main:app --reload
```

Open:

- http://127.0.0.1:8000
- API documentation: http://127.0.0.1:8000/docs

### Linux/macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/generate_sample_data.py
uvicorn app.main:app --reload
```

## Upload flow

1. Open **Upload Data**.
2. Upload one or more `.xlsx` files.
3. The application detects whether each file contains incidents, changes, problems, or RITMs.
4. Select an application and reporting month on the dashboard.
5. Review KPIs and insights.
6. Export Excel, PowerPoint, or PDF.

## Supported source-column aliases

The normalizer accepts common ServiceNow names such as:

- `Number`, `Ticket Number`, `Incident`
- `Application`, `Business Application`, `Service Offering`
- `Opened`, `Opened At`, `Created`
- `Closed`, `Closed At`, `Resolved`
- `Priority`, `Severity`
- `State`, `Status`
- `Assignment Group`, `Resolver Group`
- `Short Description`, `Description`
- `Configuration Item`, `CI`
- `Close Code`, `Resolution Code`
- `SLA Breached`, `Made SLA`
- `Change Type`, `Risk`, `Category`
- `Problem`, `Parent Problem`
- `Requested Item`, `Catalog Item`

Add organization-specific aliases in `app/services/normalizer.py`.

## Current MVP boundaries

- Data is stored locally in SQLite and normalized CSV files.
- Authentication and role-based access are not included yet.
- ServiceNow API integration is not included yet.
- AI insights use deterministic rules so the app runs without an external model.
- Direct Power BI publishing and email distribution are planned for later phases.

## Recommended enterprise hardening

- PostgreSQL
- SSO/OAuth2
- Role-based access
- Antivirus scanning for uploads
- Object storage
- Background job queue
- ServiceNow REST integration
- Audit logging
- Data retention controls
- LLM gateway with approved internal model
