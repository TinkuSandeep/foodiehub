import pandas as pd
from app.services.analytics import build_summary

def test_summary_counts():
    df = pd.DataFrame([
        {
            "ticket_type": "incident", "priority": "P2", "opened_at": "2026-01-01",
            "closed_at": "2026-01-02", "sla_breached": "Yes", "reopened": 0,
            "text_blob": "database connection issue", "assignment_group": "App Support",
            "configuration_item": "api", "application": "ODIN", "state": "Closed",
            "change_type": "", "success": ""
        },
        {
            "ticket_type": "change", "priority": "", "opened_at": "2026-01-01",
            "closed_at": "2026-01-01", "sla_breached": "", "reopened": 0,
            "text_blob": "standard change", "assignment_group": "",
            "configuration_item": "", "application": "ODIN", "state": "Closed Complete",
            "change_type": "Standard", "success": "Successful"
        },
    ])
    for col in ["number", "assigned_to", "short_description", "description", "category", "subcategory",
                "close_code", "caused_by_change", "problem", "catalog_item", "approval", "risk", "due_date", "source_file"]:
        if col not in df:
            df[col] = None
    summary = build_summary(df)
    assert summary["totals"]["incidents"] == 1
    assert summary["totals"]["changes"] == 1
    assert summary["incident"]["priority"]["P2"] == 1
