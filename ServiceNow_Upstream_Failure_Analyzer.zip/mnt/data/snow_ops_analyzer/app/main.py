from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.services.analyzer import AnalysisResult, analyze
from app.services.reports import create_excel, create_pdf, create_word, problem_statement, recommendation_text

BASE_DIR = Path(__file__).resolve().parent.parent
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="ServiceNow Upstream Failure Analyzer", version="1.0.0")
app.mount("/static", StaticFiles(directory=BASE_DIR / "app" / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "app" / "templates")
RUNS: dict[str, AnalysisResult] = {}

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/analyze")
async def analyze_files(incident_file: UploadFile = File(...), change_file: UploadFile = File(...)):
    for f in [incident_file, change_file]:
        if not f.filename or not f.filename.lower().endswith((".xlsx", ".xls")):
            raise HTTPException(status_code=400, detail="Please upload Excel files (.xlsx or .xls).")
    try:
        result = analyze(await incident_file.read(), await change_file.read(), OUTPUT_DIR)
        RUNS[result.run_id] = result
        create_excel(result.output_dir / "management_analysis.xlsx", result.incidents, result.changes, result.correlated, result.summary)
        create_word(result.output_dir / "management_summary.docx", result.summary, result.correlated)
        create_pdf(result.output_dir / "management_summary.pdf", result.summary)
        payload = dict(result.summary)
        payload.update({
            "run_id": result.run_id,
            "problem_statement": problem_statement(result.summary),
            "recommendation": recommendation_text(),
            "sample_cases": result.correlated.head(25).fillna("").astype(str).to_dict(orient="records"),
        })
        return JSONResponse(payload)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {exc}") from exc

@app.get("/download/{run_id}/{file_type}")
def download(run_id: str, file_type: str):
    if run_id not in RUNS:
        run_path = OUTPUT_DIR / run_id
        if not run_path.exists():
            raise HTTPException(status_code=404, detail="Analysis run not found.")
    mapping = {
        "excel": "management_analysis.xlsx",
        "word": "management_summary.docx",
        "pdf": "management_summary.pdf",
        "csv": "correlated_cases.csv",
    }
    if file_type not in mapping:
        raise HTTPException(status_code=400, detail="Unsupported report type.")
    path = OUTPUT_DIR / run_id / mapping[file_type]
    if not path.exists():
        raise HTTPException(status_code=404, detail="Report not found.")
    return FileResponse(path, filename=path.name)
