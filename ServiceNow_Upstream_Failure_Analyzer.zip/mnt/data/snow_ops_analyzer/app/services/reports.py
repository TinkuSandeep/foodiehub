from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
from docx import Document
from docx.shared import Inches
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def problem_statement(summary: dict[str, Any]) -> str:
    return (
        f"From the uploaded 2026 ServiceNow data, {summary['upstream_file_incidents']} incidents were identified as "
        f"upstream-file-related job failures. {summary['correlated_standard_changes']} standard changes were correlated "
        f"to these incidents, representing an automation opportunity of {summary['automation_opportunity_pct']}%. "
        f"The current operating model requires teams to inspect SSIS/AutoSys logs, contact development and source teams, "
        f"wait for file arrival, raise a standard change, restart jobs, validate completion, communicate status, and close records. "
        f"The estimated manual effort represented by the analyzed records is approximately "
        f"{summary['estimated_manual_effort_hours']} hours."
    )


def recommendation_text() -> str:
    return (
        "Implement an event-driven recovery workflow that monitors expected file arrival, validates the file, correlates or creates "
        "the incident, obtains the approved standard-change path, triggers the appropriate AutoSys or SSIS recovery action, validates "
        "job success and downstream data completion, updates ServiceNow work notes, sends notifications, and closes the records with "
        "a complete audit trail. Keep human approval for exceptions, failed validations, or non-standard restart requests."
    )


def create_excel(path: Path, incidents: pd.DataFrame, changes: pd.DataFrame, correlated: pd.DataFrame, summary: dict[str, Any]) -> None:
    metrics = pd.DataFrame([{"Metric": k.replace("_", " ").title(), "Value": json.dumps(v) if isinstance(v, dict) else v} for k, v in summary.items()])
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        metrics.to_excel(writer, sheet_name="Executive Summary", index=False)
        correlated.to_excel(writer, sheet_name="Correlated Cases", index=False)
        incidents.to_excel(writer, sheet_name="Normalized Incidents", index=False)
        changes.to_excel(writer, sheet_name="Normalized Changes", index=False)
        for ws in writer.book.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for col in ws.columns:
                width = min(max(len(str(cell.value or "")) for cell in col) + 2, 45)
                ws.column_dimensions[col[0].column_letter].width = width


def create_word(path: Path, summary: dict[str, Any], correlated: pd.DataFrame) -> None:
    doc = Document()
    doc.add_heading("Upstream File Failure Operational Analysis", 0)
    doc.add_paragraph("Management-ready analysis generated from ServiceNow incident and standard-change exports.")
    doc.add_heading("Executive Summary", level=1)
    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    table.rows[0].cells[0].text = "Metric"
    table.rows[0].cells[1].text = "Value"
    key_metrics = [
        ("Incidents uploaded", summary["total_incidents_uploaded"]),
        ("Standard changes uploaded", summary["total_changes_uploaded"]),
        ("Upstream file incidents", summary["upstream_file_incidents"]),
        ("Correlated standard changes", summary["correlated_standard_changes"]),
        ("Average resolution time (hours)", summary["average_resolution_hours"]),
        ("Estimated manual effort (hours)", summary["estimated_manual_effort_hours"]),
        ("Automation opportunity", f"{summary['automation_opportunity_pct']}%"),
    ]
    for name, value in key_metrics:
        cells = table.add_row().cells
        cells[0].text = str(name)
        cells[1].text = str(value)
    doc.add_heading("Problem Statement", level=1)
    doc.add_paragraph(problem_statement(summary))
    doc.add_heading("Recommended Target-State Automation", level=1)
    doc.add_paragraph(recommendation_text())
    doc.add_heading("Top Applications", level=1)
    for app, count in summary.get("top_applications", {}).items():
        doc.add_paragraph(f"{app}: {count}", style="List Bullet")
    doc.add_heading("Correlated Record Sample", level=1)
    if correlated.empty:
        doc.add_paragraph("No upstream file incidents were detected in the uploaded data.")
    else:
        sample = correlated.head(20)
        t = doc.add_table(rows=1, cols=5)
        t.style = "Table Grid"
        for idx, header in enumerate(["Incident", "Change", "Application", "Platform", "Score"]):
            t.rows[0].cells[idx].text = header
        for _, row in sample.iterrows():
            cells = t.add_row().cells
            vals = [row.get("incident_number", ""), row.get("change_number", ""), row.get("application", ""), row.get("job_platform", ""), row.get("correlation_score", "")]
            for idx, val in enumerate(vals):
                cells[idx].text = str(val)
    doc.add_heading("Suggested Next Steps", level=1)
    for item in [
        "Validate the classified records with application SMEs.",
        "Confirm expected file names, schedules, source paths, and downstream jobs per application.",
        "Define standard-change approval rules and exception handling.",
        "Pilot one high-volume application before expanding to other platforms.",
        "Measure incident reduction, MTTR reduction, and manual hours saved.",
    ]:
        doc.add_paragraph(item, style="List Number")
    doc.save(path)


def create_pdf(path: Path, summary: dict[str, Any]) -> None:
    c = canvas.Canvas(str(path), pagesize=A4)
    width, height = A4
    y = height - 55
    c.setFont("Helvetica-Bold", 16)
    c.drawString(45, y, "Upstream File Failure Operational Analysis")
    y -= 35
    c.setFont("Helvetica", 10)
    lines = [
        f"Incidents uploaded: {summary['total_incidents_uploaded']}",
        f"Standard changes uploaded: {summary['total_changes_uploaded']}",
        f"Upstream file incidents: {summary['upstream_file_incidents']}",
        f"Correlated standard changes: {summary['correlated_standard_changes']}",
        f"Average resolution hours: {summary['average_resolution_hours']}",
        f"Estimated manual effort hours: {summary['estimated_manual_effort_hours']}",
        f"Automation opportunity: {summary['automation_opportunity_pct']}%",
    ]
    for line in lines:
        c.drawString(45, y, line)
        y -= 18
    y -= 15
    c.setFont("Helvetica-Bold", 12)
    c.drawString(45, y, "Problem Statement")
    y -= 20
    c.setFont("Helvetica", 9)
    text = c.beginText(45, y)
    text.setLeading(13)
    words = problem_statement(summary).split()
    current = ""
    for word in words:
        if len(current + " " + word) > 105:
            text.textLine(current)
            current = word
        else:
            current = (current + " " + word).strip()
    if current:
        text.textLine(current)
    c.drawText(text)
    c.save()
