from __future__ import annotations

import io
import re
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from rapidfuzz import fuzz

INCIDENT_ALIASES = {
    "number": ["number", "incident", "incident number", "ticket", "ticket number"],
    "short_description": ["short description", "description", "summary", "title"],
    "description": ["description", "details", "work notes", "comments", "close notes"],
    "opened_at": ["opened", "opened at", "created", "created at"],
    "closed_at": ["closed", "closed at", "resolved", "resolved at"],
    "assignment_group": ["assignment group", "support group", "group"],
    "application": ["application", "business service", "configuration item", "ci", "service"],
    "state": ["state", "status"],
}

CHANGE_ALIASES = {
    "number": ["number", "change", "change number", "standard change", "ticket"],
    "short_description": ["short description", "description", "summary", "title"],
    "description": ["description", "details", "work notes", "comments", "close notes", "implementation plan"],
    "opened_at": ["opened", "opened at", "created", "created at", "planned start"],
    "closed_at": ["closed", "closed at", "completed", "completed at", "planned end"],
    "assignment_group": ["assignment group", "support group", "group"],
    "application": ["application", "business service", "configuration item", "ci", "service"],
    "state": ["state", "status"],
}

UPSTREAM_TERMS = [
    "upstream", "source file", "file delay", "file delayed", "file not received",
    "file unavailable", "waiting for file", "missing file", "late file", "input file",
    "nas", "landing path", "landing folder", "source team", "file arrival",
]
JOB_TERMS = ["autosys", "ssis", "batch", "job failed", "job failure", "rerun", "restart job", "re-start job"]
RECOVERY_TERMS = ["file available", "file received", "restart", "rerun", "re-run", "completed successfully", "job success"]

@dataclass
class AnalysisResult:
    run_id: str
    incidents: pd.DataFrame
    changes: pd.DataFrame
    correlated: pd.DataFrame
    summary: dict[str, Any]
    output_dir: Path


def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _find_column(columns: list[str], aliases: list[str]) -> str | None:
    normalized = {_norm(c): c for c in columns}
    for alias in aliases:
        if alias in normalized:
            return normalized[alias]
    for alias in aliases:
        for n, original in normalized.items():
            if alias in n or n in alias:
                return original
    return None


def normalize_frame(df: pd.DataFrame, kind: str) -> pd.DataFrame:
    aliases = INCIDENT_ALIASES if kind == "incident" else CHANGE_ALIASES
    out = pd.DataFrame()
    for canonical, candidates in aliases.items():
        col = _find_column(list(df.columns), candidates)
        out[canonical] = df[col] if col else ""
    for field in ["number", "short_description", "description", "assignment_group", "application", "state"]:
        out[field] = out[field].fillna("").astype(str).str.strip()
    for field in ["opened_at", "closed_at"]:
        out[field] = pd.to_datetime(out[field], errors="coerce")
    out["record_type"] = kind
    out["text"] = (
        out["short_description"].fillna("") + " " +
        out["description"].fillna("") + " " +
        out["application"].fillna("")
    ).str.lower()
    out["is_upstream_file_failure"] = out["text"].apply(classify_upstream)
    out["job_platform"] = out["text"].apply(classify_platform)
    out["application_normalized"] = out["application"].replace("", pd.NA).fillna("Unknown")
    out["duration_hours"] = ((out["closed_at"] - out["opened_at"]).dt.total_seconds() / 3600).round(2)
    return out


def classify_upstream(text: str) -> bool:
    t = _norm(text)
    upstream_score = sum(term in t for term in UPSTREAM_TERMS)
    job_score = sum(term in t for term in JOB_TERMS)
    return upstream_score >= 1 and job_score >= 1


def classify_platform(text: str) -> str:
    t = _norm(text)
    has_auto = "autosys" in t
    has_ssis = "ssis" in t
    if has_auto and has_ssis:
        return "AutoSys + SSIS"
    if has_auto:
        return "AutoSys"
    if has_ssis:
        return "SSIS"
    if "batch" in t or "job" in t:
        return "Other Batch"
    return "Unknown"


def read_excel_bytes(content: bytes) -> pd.DataFrame:
    return pd.read_excel(io.BytesIO(content), sheet_name=0)


def correlate(incidents: pd.DataFrame, changes: pd.DataFrame) -> pd.DataFrame:
    inc = incidents[incidents["is_upstream_file_failure"]].copy()
    chg = changes.copy()
    rows: list[dict[str, Any]] = []

    for _, i in inc.iterrows():
        best: tuple[float, pd.Series | None] = (0.0, None)
        i_text = f"{i['short_description']} {i['description']} {i['application']}".lower()
        for _, c in chg.iterrows():
            c_text = f"{c['short_description']} {c['description']} {c['application']}".lower()
            score = float(fuzz.token_set_ratio(i_text, c_text))
            if i["application"] and c["application"] and _norm(i["application"]) == _norm(c["application"]):
                score += 18
            if i["job_platform"] == c["job_platform"] and i["job_platform"] != "Unknown":
                score += 8
            if pd.notna(i["opened_at"]) and pd.notna(c["opened_at"]):
                hours = abs((c["opened_at"] - i["opened_at"]).total_seconds()) / 3600
                if hours <= 72:
                    score += max(0, 15 - hours / 6)
                elif hours > 168:
                    score -= 15
            if score > best[0]:
                best = (score, c)

        c = best[1] if best[0] >= 48 else None
        rows.append({
            "incident_number": i["number"],
            "incident_opened_at": i["opened_at"],
            "incident_closed_at": i["closed_at"],
            "application": i["application_normalized"],
            "job_platform": i["job_platform"],
            "incident_summary": i["short_description"],
            "change_number": c["number"] if c is not None else "",
            "change_opened_at": c["opened_at"] if c is not None else pd.NaT,
            "change_state": c["state"] if c is not None else "",
            "correlation_score": round(best[0], 1) if c is not None else 0,
            "matched": c is not None,
            "manual_recovery_detected": any(term in i_text for term in RECOVERY_TERMS) or (c is not None),
            "resolution_hours": i["duration_hours"],
        })
    return pd.DataFrame(rows)


def build_summary(incidents: pd.DataFrame, changes: pd.DataFrame, correlated: pd.DataFrame) -> dict[str, Any]:
    upstream_inc = incidents[incidents["is_upstream_file_failure"]]
    matched = correlated[correlated["matched"] == True] if not correlated.empty else correlated
    hours = pd.to_numeric(upstream_inc["duration_hours"], errors="coerce")
    estimated_minutes = int(len(upstream_inc) * 75 + len(matched) * 30)
    app_counts = upstream_inc["application_normalized"].value_counts().head(10).to_dict()
    platform_counts = upstream_inc["job_platform"].value_counts().to_dict()
    monthly = {}
    if not upstream_inc.empty:
        monthly = upstream_inc.dropna(subset=["opened_at"]).assign(month=lambda x: x["opened_at"].dt.strftime("%Y-%m"))["month"].value_counts().sort_index().to_dict()
    return {
        "total_incidents_uploaded": int(len(incidents)),
        "total_changes_uploaded": int(len(changes)),
        "upstream_file_incidents": int(len(upstream_inc)),
        "correlated_standard_changes": int(len(matched)),
        "unmatched_upstream_incidents": int(len(correlated) - len(matched)),
        "average_resolution_hours": round(float(hours.mean()), 2) if hours.notna().any() else 0,
        "estimated_manual_effort_hours": round(estimated_minutes / 60, 1),
        "top_applications": app_counts,
        "platform_distribution": platform_counts,
        "monthly_trend": monthly,
        "automation_opportunity_pct": round((len(matched) / len(upstream_inc) * 100), 1) if len(upstream_inc) else 0,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }


def analyze(incident_bytes: bytes, change_bytes: bytes, base_output: Path) -> AnalysisResult:
    run_id = uuid.uuid4().hex[:10]
    output_dir = base_output / run_id
    output_dir.mkdir(parents=True, exist_ok=True)
    incidents = normalize_frame(read_excel_bytes(incident_bytes), "incident")
    changes = normalize_frame(read_excel_bytes(change_bytes), "change")
    correlated = correlate(incidents, changes)
    summary = build_summary(incidents, changes, correlated)
    incidents.to_csv(output_dir / "normalized_incidents.csv", index=False)
    changes.to_csv(output_dir / "normalized_changes.csv", index=False)
    correlated.to_csv(output_dir / "correlated_cases.csv", index=False)
    return AnalysisResult(run_id, incidents, changes, correlated, summary, output_dir)
