from __future__ import annotations
import io,re,uuid,json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any
import pandas as pd
from rapidfuzz import fuzz
TYPES={'incident':'Incident','standard_change':'Standard Change','normal_change':'Normal Change','emergency_change':'Emergency Change Request','problem':'Problem'}
ALIASES={'number':['number','task number','ticket','incident number','change number','problem number'],'short_description':['short description','summary','title'],'description':['description','details','work notes','comments','close notes','resolution notes','implementation plan','justification','root cause notes'],'opened_at':['opened','opened at','created','created at','sys created on','planned start'],'closed_at':['closed','closed at','resolved','resolved at','completed','planned end'],'application':['application','business application','application name','app name'],'business_service':['business service','service'],'configuration_item':['configuration item','config item','ci'],'assignment_group':['assignment group','support group','group'],'state':['state','status'],'priority':['priority','severity'],'impact':['impact','business impact'],'risk':['risk','risk level'],'category':['category','subcategory','type','change type'],'change_outcome':['outcome','change outcome','result','close code'],'linked_incident':['linked incident','incident number'],'linked_problem':['linked problem','problem number']}
RULES=[('Upstream File Missing / Delayed',['file not received','file not available','file missing','late file','delayed file','awaiting file','upstream file','source file']),('File Data Quality / Format',['corrupt file','invalid data','bad data','malformed','extra character','delimiter','column mismatch','missing column','header mismatch','record length','field length','value too long','truncation','schema mismatch','invalid format','encoding']),('File Transfer / Connectivity',['sftp','ftp','file transfer','connection timeout','network issue','permission denied','authentication failed','path not found','nas unavailable']),('AutoSys / Scheduler',['autosys','autorep','jil','box job','scheduler','force start','job failed','batch failed','restart job','rerun']),('SSIS / ETL',['ssis','dtsx','package failed','etl','data load','load failed']),('Database',['database','sql','oracle','postgres','db2','deadlock','constraint violation','insert failed','stored procedure']),('Application / Code',['application error','code defect','bug','exception','service unavailable','api error','deployment issue','configuration issue']),('Infrastructure / Server',['server down','host down','cpu','disk space','filesystem full','service stopped','infrastructure','virtual machine']),('Access / Security',['access issue','access denied','permission','authentication','authorization','password','account locked','certificate','security']),('Performance / Capacity',['slow','latency','performance','timeout','capacity','high cpu','high memory']),('Monitoring / Alert',['monitoring alert','alert triggered','threshold','false alert','health check','heartbeat']),('Release / Deployment',['release','deployment','post deployment','rollback','backout','implementation failed','change failed']),('Business / Data Request',['data request','business request','ad hoc','report request','extract request','user request'])]
PLAT=[('AutoSys',['autosys','autorep','jil','box job']),('SSIS',['ssis','dtsx']),('Database',['oracle','sql server','postgres','db2','database']),('SFTP / File Transfer',['sftp','ftp','file transfer']),('Application / API',['api','application','service']),('Infrastructure',['server','host','vm','disk','cpu','memory'])]
def norm(v):
 if v is None or (isinstance(v,float) and pd.isna(v)): return ''
 return re.sub(r'\s+',' ',re.sub(r'[_/\\-]+',' ',str(v).strip().lower()))
def find(cols,als):
 m={norm(c):c for c in cols}
 for a in als:
  if norm(a) in m:return m[norm(a)]
 for a in als:
  for n,o in m.items():
   if norm(a) in n or n in norm(a):return o
 return None
def read_excel(b):
 x=pd.ExcelFile(io.BytesIO(b)); fs=[]
 for s in x.sheet_names:
  d=pd.read_excel(x,sheet_name=s).dropna(how='all').dropna(axis=1,how='all')
  if not d.empty:fs.append(d)
 if not fs:raise ValueError('No usable rows found')
 return max(fs,key=lambda d:int(d.notna().sum().sum()))
def cat(t):
 n=norm(t); hits=[]
 for c,ts in RULES:
  f=[x for x in ts if x in n]
  if f:hits.append((c,len(f),f))
 if not hits:return ('Other / Unclassified','',0.0)
 c,k,f=max(hits,key=lambda x:x[1]);return(c,', '.join(f[:8]),min(100,40+k*15))
def plat(t):
 n=norm(t); f=[c for c,ts in PLAT if any(x in n for x in ts)];return ' + '.join(f[:2]) if f else 'Unknown'
def outcome(t):
 n=norm(t)
 if any(x in n for x in ['failed','rolled back','rollback','backout']):return 'Failed / Rolled Back'
 if any(x in n for x in ['cancelled','canceled','withdrawn']):return 'Cancelled / Not Implemented'
 if any(x in n for x in ['successful','success','implemented','completed']):return 'Successful'
 return 'Unknown'
def normalize(df,typ):
 df=df.copy();df.columns=[str(c).strip() for c in df.columns];o=pd.DataFrame(index=df.index)
 for k,a in ALIASES.items():
  c=find(list(df.columns),a);o[k]=df[c] if c else ''
 for k in ALIASES:
  if k not in ['opened_at','closed_at']:o[k]=o[k].fillna('').astype(str).str.strip()
 o['opened_at']=pd.to_datetime(o['opened_at'],errors='coerce',format='mixed');o['closed_at']=pd.to_datetime(o['closed_at'],errors='coerce',format='mixed')
 p={'incident':'INC','standard_change':'STD','normal_change':'CHG','emergency_change':'ECR','problem':'PRB'}[typ]
 miss=o.number.eq('');o.loc[miss,'number']=[f'{p}-ROW-{i+2}' for i in o.index[miss]]
 extra=pd.Series('',index=df.index,dtype='object')
 for c in df.columns:
  if any(x in norm(c) for x in ['description','notes','comments','summary','title','resolution','close','implementation','justification','category','application','service','configuration item','cause']):extra=extra.str.cat(df[c].fillna('').astype(str),sep=' ')
 o['combined_text']=(o.short_description+' '+o.description+' '+o.application+' '+o.business_service+' '+o.configuration_item+' '+o.category+' '+extra).str.lower().str.replace(r'\s+',' ',regex=True)
 z=o.combined_text.apply(cat);o['analysis_category']=z.str[0];o['matched_keywords']=z.str[1];o['classification_confidence']=z.str[2];o['platform']=o.combined_text.apply(plat)
 o['application_normalized']=o.application.mask(o.application.eq(''),o.business_service).mask(lambda s:s.eq(''),o.configuration_item).replace('','Unknown')
 o['duration_hours']=((o.closed_at-o.opened_at).dt.total_seconds()/3600).where(lambda s:s>=0).round(2);o['record_type']=typ;o['record_type_label']=TYPES[typ]
 o['change_outcome_normalized']=(o.change_outcome+' '+o.state+' '+o.description).apply(outcome) if typ!='incident' and typ!='problem' else ''
 return o
def score(a,b):
 s=float(fuzz.token_set_ratio(norm(a.short_description+' '+a.description),norm(b.short_description+' '+b.description)))
 if norm(a.application_normalized)==norm(b.application_normalized) and norm(a.application_normalized) not in ('','unknown'):s+=25
 if a.analysis_category==b.analysis_category and a.analysis_category!='Other / Unclassified':s+=15
 if a.platform==b.platform and a.platform!='Unknown':s+=10
 if pd.notna(a.opened_at) and pd.notna(b.opened_at):
  h=abs((b.opened_at-a.opened_at).total_seconds())/3600;s+=20 if h<=24 else 12 if h<=72 else 6 if h<=168 else -20 if h>720 else 0
 return s
def correlate(r):
 inc=r.get('incident',pd.DataFrame());tar=pd.concat([r[k] for k in TYPES if k!='incident' and not r.get(k,pd.DataFrame()).empty],ignore_index=True) if any(not r.get(k,pd.DataFrame()).empty for k in TYPES if k!='incident') else pd.DataFrame();rows=[]
 for _,i in inc.iterrows():
  best=None;bs=0
  for _,t in tar.iterrows():
   sc=score(i,t)
   if sc>bs:bs,best=sc,t
  m=best is not None and bs>=48;rows.append({'incident_number':i.number,'incident_application':i.application_normalized,'incident_category':i.analysis_category,'related_record_number':best.number if m else '','related_record_type':best.record_type_label if m else '','correlation_score':round(bs,1) if m else 0,'matched':m})
 return pd.DataFrame(rows)
def recurring(inc):
 rows=[]
 if inc.empty:return pd.DataFrame()
 for (a,c),g in inc.groupby(['application_normalized','analysis_category']):
  if len(g)>=2:rows.append({'application':a,'category':c,'incident_count':len(g),'first_seen':g.opened_at.min(),'last_seen':g.opened_at.max(),'average_resolution_hours':round(pd.to_numeric(g.duration_hours,errors='coerce').mean(),2),'sample_incidents':', '.join(g.number.astype(str).head(8)),'problem_candidate':len(g)>=3})
 return pd.DataFrame(rows).sort_values('incident_count',ascending=False) if rows else pd.DataFrame()
def app_summary(r,rec):
 apps=set();[apps.update(f.application_normalized.dropna().astype(str)) for f in r.values() if not f.empty];rows=[]
 for a in sorted(apps):
  x={'application':a}
  for t in TYPES:x[t+'_count']=int((r[t].application_normalized==a).sum()) if not r[t].empty else 0
  inc=r['incident'];ai=inc[inc.application_normalized==a] if not inc.empty else pd.DataFrame();x['avg_resolution_hours']=round(pd.to_numeric(ai.duration_hours,errors='coerce').mean(),2) if not ai.empty else 0;x['top_incident_category']=ai.analysis_category.value_counts().index[0] if not ai.empty else '';x['problem_candidates']=int(rec[(rec.application==a)&(rec.problem_candidate==True)].shape[0]) if not rec.empty else 0
  cs=[r[t][r[t].application_normalized==a] for t in ['standard_change','normal_change','emergency_change'] if not r[t].empty];ch=pd.concat(cs,ignore_index=True) if cs else pd.DataFrame();x['change_success_rate_pct']=round((ch.change_outcome_normalized=='Successful').sum()/len(ch)*100,1) if len(ch) else 0;x['change_failure_rate_pct']=round((ch.change_outcome_normalized=='Failed / Rolled Back').sum()/len(ch)*100,1) if len(ch) else 0;x['operational_risk_score']=round(x['incident_count']+2*x['emergency_change_count']+3*x['problem_candidates']+x['change_failure_rate_pct']/10,1);rows.append(x)
 return pd.DataFrame(rows).sort_values('operational_risk_score',ascending=False) if rows else pd.DataFrame()
@dataclass
class Result:run_id:str;records:dict;correlations:pd.DataFrame;recurring_clusters:pd.DataFrame;application_summary:pd.DataFrame;enterprise_summary:dict;output_dir:Path
def analyze(files,base):
 rid=uuid.uuid4().hex[:10];od=base/rid;od.mkdir(parents=True,exist_ok=True);r={t:normalize(read_excel(files[t]),t) if files.get(t) else pd.DataFrame() for t in TYPES};co=correlate(r);recur=recurring(r['incident']);apps=app_summary(r,recur);s={'generated_at':datetime.now().isoformat(timespec='seconds'),'applications_analyzed':len(apps),'correlated_incidents':int(co.matched.sum()) if not co.empty else 0,'problem_candidates':int(recur.problem_candidate.sum()) if not recur.empty else 0}
 for t in TYPES:s[t+'_count']=len(r[t])
 allc=pd.concat([r[t] for t in ['standard_change','normal_change','emergency_change'] if not r[t].empty],ignore_index=True) if any(not r[t].empty for t in ['standard_change','normal_change','emergency_change']) else pd.DataFrame();s['overall_change_success_rate_pct']=round((allc.change_outcome_normalized=='Successful').sum()/len(allc)*100,1) if len(allc) else 0;e=r['emergency_change'];s['ecr_conversion_candidates']=int((e.groupby(['application_normalized','analysis_category']).size()>=2).sum()) if not e.empty else 0
 for t,f in r.items():
  if not f.empty:f.to_csv(od/f'{t}_analysis.csv',index=False,encoding='utf-8-sig')
 co.to_csv(od/'correlations.csv',index=False);recur.to_csv(od/'recurring_incident_clusters.csv',index=False);apps.to_csv(od/'application_summary.csv',index=False);(od/'enterprise_summary.json').write_text(json.dumps(s,indent=2,default=str));return Result(rid,r,co,recur,apps,s,od)
