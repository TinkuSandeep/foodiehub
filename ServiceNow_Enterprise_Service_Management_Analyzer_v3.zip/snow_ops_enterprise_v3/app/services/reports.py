import pandas as pd
def excel(result):
 p=result.output_dir/'enterprise_service_management_analysis.xlsx'
 with pd.ExcelWriter(p,engine='openpyxl') as w:
  [f.to_excel(w,sheet_name=t[:31],index=False) for t,f in result.records.items() if not f.empty]
  result.correlations.to_excel(w,sheet_name='correlations',index=False);result.recurring_clusters.to_excel(w,sheet_name='problem_candidates',index=False);result.application_summary.to_excel(w,sheet_name='application_summary',index=False);pd.DataFrame([result.enterprise_summary]).to_excel(w,sheet_name='enterprise_summary',index=False)
 return p
def summary(result):
 s=result.enterprise_summary;p=result.output_dir/'management_summary.txt';p.write_text('\n'.join(['ENTERPRISE SERVICE MANAGEMENT ANALYSIS','',f"Applications: {s['applications_analyzed']}",f"Incidents: {s['incident_count']}",f"Standard changes: {s['standard_change_count']}",f"Normal changes: {s['normal_change_count']}",f"Emergency changes: {s['emergency_change_count']}",f"Problems: {s['problem_count']}",f"Correlated incidents: {s['correlated_incidents']}",f"Problem candidates: {s['problem_candidates']}",f"Change success rate: {s['overall_change_success_rate_pct']}%",f"ECR conversion candidates: {s['ecr_conversion_candidates']}"]),encoding='utf-8');return p
