from pathlib import Path
from fastapi import FastAPI,File,Request,UploadFile
from fastapi.responses import FileResponse,HTMLResponse,JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.services.analyzer import analyze
from app.services.reports import excel,summary
B=Path(__file__).resolve().parent.parent;O=B/'outputs';O.mkdir(exist_ok=True);RUNS={};app=FastAPI(title='Enterprise Service Management Analyzer',version='3.0.0');app.mount('/static',StaticFiles(directory=B/'app/static'),name='static');tpl=Jinja2Templates(directory=B/'app/templates')
@app.get('/',response_class=HTMLResponse)
async def home(request:Request):return tpl.TemplateResponse(request=request,name='index.html',context={})
@app.post('/analyze')
async def run(incident_file:UploadFile=File(...),standard_change_file:UploadFile|None=File(None),normal_change_file:UploadFile|None=File(None),emergency_change_file:UploadFile|None=File(None),problem_file:UploadFile|None=File(None)):
 try:
  fs={'incident':await incident_file.read(),'standard_change':await standard_change_file.read() if standard_change_file else None,'normal_change':await normal_change_file.read() if normal_change_file else None,'emergency_change':await emergency_change_file.read() if emergency_change_file else None,'problem':await problem_file.read() if problem_file else None};r=analyze(fs,O);x=excel(r);s=summary(r);RUNS[r.run_id]={'excel':x,'summary':s};return {'run_id':r.run_id,**r.enterprise_summary,'sample_applications':r.application_summary.head(20).fillna('').to_dict('records'),'sample_problem_candidates':r.recurring_clusters.head(20).fillna('').to_dict('records')}
 except Exception as e:return JSONResponse(status_code=500,content={'detail':f'Analysis failed: {e}'})
@app.get('/download/{run_id}/{kind}')
async def dl(run_id:str,kind:str):
 r=RUNS.get(run_id);return FileResponse(r[kind],filename=r[kind].name) if r and kind in r else JSONResponse(status_code=404,content={'detail':'Not found'})
@app.get('/health')
async def health():return {'status':'ok','version':'3.0.0'}
