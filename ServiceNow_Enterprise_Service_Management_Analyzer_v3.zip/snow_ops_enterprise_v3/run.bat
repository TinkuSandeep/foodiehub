@echo off
if not exist venv py -3.13 -m venv venv
call venv\Scripts\activate
python -m pip install --no-user -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
