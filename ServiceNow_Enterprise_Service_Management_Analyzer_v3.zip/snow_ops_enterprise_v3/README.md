# Enterprise Service Management Analyzer v3

Analyzes incidents, standard changes, normal changes, emergency change requests, and problems by application.

## Run
```cmd
py -3.13 -m venv venv
venv\Scripts\activate
python -m pip install --no-user -r requirements.txt
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
Open http://localhost:8000

This is an Excel-based enterprise prototype. Production rollout should add ServiceNow APIs, CMDB mappings, SSO/RBAC, PostgreSQL, background processing, audit logs, human review, Outlook/Graph integration, and CI/CD.
